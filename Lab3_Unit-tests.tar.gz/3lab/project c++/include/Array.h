#pragma once
#include <iostream>
#include <vector>

class Array {
private:
  std::vector<int> data;

public:
  void push(int value);
  void insertAt(int index, int value);
  void delAt(int index);
  int get(int index) const;
  void set(int index, int value);
  size_t size() const;
  bool empty() const { return data.empty(); }
  void print() const;

  void serializeBinary(std::ostream &os) const;
  void deserializeBinary(std::istream &is);
  void serializeText(std::ostream &os) const;
  void deserializeText(std::istream &is);
};