#include "../include/CommandProcessor.h"
#include "../include/Array.h"
#include "../include/CompleteBinaryTree.h"
#include "../include/DoublyLinkedList.h"
#include "../include/HashTable.h"
#include "../include/Queue.h"
#include "../include/SinglyLinkedList.h"
#include "../include/Stack.h"

#include <cctype>
#include <fstream>
#include <iostream>
#include <sstream>

using namespace std;

void saveArrayToBinaryFile(const string &filename, const Array &arr) {
  ofstream fout(filename, ios::binary);
  if (!fout) {
    cerr << "Ошибка открытия файла для бинарной записи: " << filename << endl;
    return;
  }
  arr.serializeBinary(fout);
}

void loadArrayFromBinaryFile(const string &filename, Array &arr) {
  ifstream fin(filename, ios::binary);
  if (!fin) {
    cerr << "Ошибка открытия файла для бинарного чтения: " << filename << endl;
    return;
  }
  arr.deserializeBinary(fin);
}

void saveListToBinaryFile(const string &filename, const SinglyLinkedList &list) {
  ofstream fout(filename, ios::binary);
  if (!fout) {
    return;
  }
  list.serializeBinary(fout);
}

void loadListFromBinaryFile(const string &filename, SinglyLinkedList &list) {
  ifstream fin(filename, ios::binary);
  if (!fin) {
    list = SinglyLinkedList();
    return;
  }
  list.deserializeBinary(fin);
}

void saveDoublyListToBinaryFile(const string &filename, const DoublyLinkedList &list) {
  ofstream fout(filename, ios::binary);
  if (!fout) {
    return;
  }
  list.serializeBinary(fout);
}

void loadDoublyListFromBinaryFile(const string &filename, DoublyLinkedList &list) {
  ifstream fin(filename, ios::binary);
  if (!fin) {
    list = DoublyLinkedList();
    return;
  }
  list.deserializeBinary(fin);
}

void saveStackToBinaryFile(const string &filename, const Stack &stack) {
  ofstream fout(filename, ios::binary);
  if (!fout) {
    return;
  }
  stack.serializeBinary(fout);
}

void loadStackFromBinaryFile(const string &filename, Stack &stack) {
  ifstream fin(filename, ios::binary);
  if (!fin) {
    stack = Stack();
    return;
  }
  stack.deserializeBinary(fin);
}

void saveQueueToBinaryFile(const string &filename, const Queue &queue) {
  ofstream fout(filename, ios::binary);
  if (!fout) {
    return;
  }
  queue.serializeBinary(fout);
}

void loadQueueFromBinaryFile(const string &filename, Queue &queue) {
  ifstream fin(filename, ios::binary);
  if (!fin) {
    queue = Queue();
    return;
  }
  queue.deserializeBinary(fin);
}

void saveTreeToBinaryFile(const string &filename, const CompleteBinaryTree &tree) {
  ofstream fout(filename, ios::binary);
  if (!fout) {
    return;
  }
  tree.serializeBinary(fout);
}

void loadTreeFromBinaryFile(const string &filename, CompleteBinaryTree &tree) {
  ifstream fin(filename, ios::binary);
  if (!fin) {
    tree = CompleteBinaryTree();
    return;
  }
  tree.deserializeBinary(fin);
}

void saveHashToBinaryFile(const string &filename, const HashTable &ht) {
  ofstream fout(filename, ios::binary);
  if (!fout) {
    cerr << "Ошибка открытия файла для бинарной записи: " << filename << endl;
    return;
  }
  ht.serializeBinary(fout);
}

void loadHashFromBinaryFile(const string &filename, HashTable &ht) {
  ifstream fin(filename, ios::binary);
  if (!fin) {
    cerr << "Ошибка открытия файла для бинарного чтения: " << filename << endl;
    return;
  }
  ht.deserializeBinary(fin);
}

void loadArrayFromFile(const string &filename, Array &arr) {
  ifstream fin(filename);
  if (!fin.is_open()) {
    return;
  }
  int value;
  while (fin >> value) {
    arr.push(value);
  }
  fin.close();
}

void saveArrayToFile(const string &filename, const Array &arr) {
  ofstream fout(filename);
  if (!fout.is_open()) {
    return;
  }
  for (size_t i = 0; i < arr.size(); i++) {
    fout << arr.get(i) << " ";
  }
  fout.close();
}

void loadTreeFromFile(const string &filename, CompleteBinaryTree &tree) {
  ifstream fin(filename);
  if (!fin.is_open()) {
    return;
  }
  int value;
  while (fin >> value) {
    tree.insert(value);
  }
  fin.close();
}

void saveTreeToFile(const string &filename, const CompleteBinaryTree &tree) {
  ofstream fout(filename);
  if (!fout.is_open()) {
    return;
  }

  vector<int> keys = tree.levelOrder();
  for (size_t i = 0; i < keys.size(); ++i) {
    fout << keys[i];
    if (i + 1 < keys.size()) {
      fout << " ";
    }
  }
  fout << endl;
  fout.close();
}

void loadListFromFile(const string &filename, SinglyLinkedList &list) {
  ifstream fin(filename);
  if (!fin.is_open()) {
    return;
  }

  int value;
  while (fin >> value) {
    list.pushBack(value);
  }
  fin.close();
}

void saveListToFile(const string &filename, const SinglyLinkedList &list) {
  ofstream fout(filename);
  if (!fout.is_open()) {
    return;
  }

  for (int val : list.toVector()) {
    fout << val << " ";
  }
  fout.close();
}

void loadDoublyListFromFile(const string &filename, DoublyLinkedList &list) {
  ifstream fin(filename);
  if (!fin.is_open()) {
    return;
  }

  int value;
  while (fin >> value) {
    list.pushBack(value);
  }
  fin.close();
}

void saveDoublyListToFile(const string &filename, const DoublyLinkedList &list) {
  ofstream fout(filename);
  if (!fout.is_open()) {
    return;
  }

  for (int val : list.toVector()) {
    fout << val << " ";
  }
  fout.close();
}

void loadStackFromFile(const string &filename, Stack &stack) {
  ifstream fin(filename);
  if (!fin.is_open()) {
    return;
  }

  int value;
  while (fin >> value) {
    stack.push(value);
  }
  fin.close();
}

void saveStackToFile(const string &filename, const Stack &stack) {
  ofstream fout(filename);
  if (!fout.is_open()) {
    return;
  }

  for (int val : stack.toVector()) {
    fout << val << " ";
  }
  fout.close();
}

void loadQueueFromFile(const string &filename, Queue &queue) {
  ifstream fin(filename);
  if (!fin.is_open()) {
    return;
  }

  int value;
  while (fin >> value) {
    queue.push(value);
  }
  fin.close();
}

void saveQueueToFile(const string &filename, const Queue &queue) {
  ofstream fout(filename);
  if (!fout.is_open()) {
    return;
  }

  for (int val : queue.toVector()) {
    fout << val << " ";
  }
  fout.close();
}

static inline string ltrim(const string &s) {
  size_t i = 0;
  while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i])) != 0) {
    ++i;
  }
  return s.substr(i);
}

void loadHashFromFile(const string &filename, HashTable &ht) {
  ifstream in(filename);
  if (!in.is_open()) {
    return;
  }

  string token;
  string typeStr;
  int size_val = 11;

  if (in >> token >> typeStr && token == "TYPE") {
    HashType type = HashType::OPEN_ADDRESSING;
    if (typeStr == "CUCKOO") {
      type = HashType::SEPARATE_CHAINING;
    } else if (typeStr == "FOLDING") {
      type = HashType::FOLDING_HASHING;
    }

    in >> token >> size_val;
    ht = HashTable(size_val, type);
  } else {
    ht = HashTable(size_val, HashType::OPEN_ADDRESSING);
  }

  int key;
  int value;
  while (in >> key >> value) {
    ht.insert(key, value);
  }
}

void saveHashToFile(const string &filename, const HashTable &ht) {
  ofstream out(filename);
  if (!out.is_open()) {
    cerr << "Ошибка при открытии файла для записи.\n";
    return;
  }

  out << "TYPE ";
  switch (ht.getType()) {
  case HashType::OPEN_ADDRESSING:
    out << "DOUBLE\n";
    break;
  case HashType::SEPARATE_CHAINING:
    out << "CUCKOO\n";
    break;
  case HashType::FOLDING_HASHING:
    out << "FOLDING\n";
    break;
  }

  out << "SIZE " << ht.getSize() << "\n";

  for (const auto &p : ht.toVector()) {
    out << p.first << " " << p.second << "\n";
  }
}

static HashTable hashTable(11, HashType::OPEN_ADDRESSING);

void CommandProcessor::execute(const string &query, const string &filename) {
  istringstream iss(query);
  string command;
  iss >> command;

  if (command == "CBTINSERT") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды CBTINSERT\n";
      return;
    }
    CompleteBinaryTree tree;
    loadTreeFromFile(filename, tree);
    tree.insert(value);
    saveTreeToFile(filename, tree);
    cout << "-> вставлен " << value << endl;
  } else if (command == "CBTDEL") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды CBTDEL\n";
      return;
    }
    CompleteBinaryTree tree;
    loadTreeFromFile(filename, tree);

    if (tree.contains(value)) {
      tree.remove(value);
      saveTreeToFile(filename, tree);
      cout << "-> удалён " << value << endl;
    } else {
      cout << "Ошибка: элемент " << value << " не найден" << endl;
    }
  } else if (command == "CBTGET") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды CBTGET\n";
      return;
    }
    CompleteBinaryTree tree;
    loadTreeFromFile(filename, tree);
    cout << "-> " << (tree.contains(value) ? "TRUE" : "FALSE") << endl;
  } else if (command == "CBTVALIDATE") {
    CompleteBinaryTree tree;
    loadTreeFromFile(filename, tree);
    bool ok = tree.validate();
    cout << "-> " << (ok ? "VALID" : "INVALID") << endl;
  } else if (command == "CBTPRINT") {
    CompleteBinaryTree tree;
    loadTreeFromFile(filename, tree);
    cout << "-> ";
    tree.print();
  } else if (command == "CBTPRINT_TREE") {
    CompleteBinaryTree tree;
    loadTreeFromFile(filename, tree);
    cout << "-> Complete Binary Tree Structure:\n";
    tree.printTree();
  } else if (command == "MPUSH") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды MPUSH\n";
      return;
    }
    Array arr;
    loadArrayFromFile(filename, arr);
    arr.push(value);
    saveArrayToFile(filename, arr);
    cout << "-> добавлен " << value << endl;
  } else if (command == "MDEL") {
    int index;
    if (!(iss >> index)) {
      cerr << "Ошибка: неверный формат команды MDEL\n";
      return;
    }
    Array arr;
    loadArrayFromFile(filename, arr);

    if (index >= 0 && index < static_cast<int>(arr.size())) {
      arr.delAt(index);
      saveArrayToFile(filename, arr);
      cout << "-> удалён элемент по индексу " << index << endl;
    } else {
      cout << "Ошибка: индекс " << index << " вне диапазона" << endl;
    }
  } else if (command == "MGET") {
    int index;
    if (!(iss >> index)) {
      cerr << "Ошибка: неверный формат команды MGET\n";
      return;
    }
    Array arr;
    loadArrayFromFile(filename, arr);
    cout << "-> " << arr.get(index) << endl;
  } else if (command == "PRINTM") {
    Array arr;
    loadArrayFromFile(filename, arr);
    cout << "-> ";
    arr.print();
  } else if (command == "MINDEX") {
    int index, value;
    if (!(iss >> index >> value)) {
      cerr << "Ошибка: неверный формат команды MINDEX\n";
      return;
    }
    Array arr;
    loadArrayFromFile(filename, arr);

    if (index >= 0 && index <= static_cast<int>(arr.size())) {
      arr.insertAt(index, value);
      saveArrayToFile(filename, arr);
      cout << "-> вставлен " << value << " по индексу " << index << endl;
    } else {
      cout << "Ошибка: индекс " << index << " вне диапазона" << endl;
    }
  } else if (command == "MSET") {
    int index, value;
    if (!(iss >> index >> value)) {
      cerr << "Ошибка: неверный формат команды MSET\n";
      return;
    }
    Array arr;
    loadArrayFromFile(filename, arr);
    arr.set(index, value);
    saveArrayToFile(filename, arr);
    cout << "-> заменён элемент по индексу " << index << " на " << value << endl;
  } else if (command == "FPUSH") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды FPUSH\n";
      return;
    }
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    list.pushBack(value);
    saveListToFile(filename, list);
    cout << "-> добавлен " << value << endl;
  } else if (command == "FDEL") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды FDEL\n";
      return;
    }
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    bool ok = list.delByValue(value);
    saveListToFile(filename, list);
    if (ok) {
      cout << "-> удалён " << value << endl;
    } else {
      cout << "-> элемент " << value << " не найден" << endl;
    }
  } else if (command == "FGET") {
    int index;
    if (!(iss >> index)) {
      cerr << "Ошибка: неверный формат команды FGET\n";
      return;
    }
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    cout << "-> " << list.get(index) << endl;
  } else if (command == "PRINTF") {
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    cout << "-> ";
    list.print();
  } else if (command == "FPUSHFRONT") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды FPUSHFRONT\n";
      return;
    }
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    list.pushFront(value);
    saveListToFile(filename, list);
    cout << "-> добавлен " << value << " в голову" << endl;
  } else if (command == "FINSERTBEFORE") {
    int target, value;
    if (!(iss >> target >> value)) {
      cerr << "Ошибка: неверный формат команды FINSERTBEFORE\n";
      return;
    }
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    list.insertBefore(target, value);
    saveListToFile(filename, list);
    cout << "-> вставлен " << value << " перед " << target << endl;
  } else if (command == "FINSERTAFTER") {
    int target, value;
    if (!(iss >> target >> value)) {
      cerr << "Ошибка: неверный формат команды FINSERTAFTER\n";
      return;
    }
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    list.insertAfter(target, value);
    saveListToFile(filename, list);
    cout << "-> вставлен " << value << " после " << target << endl;
  } else if (command == "FDELFRONT") {
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    bool ok = list.delFront();
    saveListToFile(filename, list);
    if (ok) {
      cout << "-> удалён первый элемент" << endl;
    } else {
      cout << "Ошибка: список пуст" << endl;
    }
  } else if (command == "FDELBACK") {
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    bool ok = list.delBack();
    saveListToFile(filename, list);
    if (ok) {
      cout << "-> удалён последний элемент" << endl;
    } else {
      cout << "Ошибка: список пуст" << endl;
    }
  } else if (command == "FCONTAINS") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды FCONTAINS\n";
      return;
    }
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    bool found = list.contains(value);
    cout << "-> " << (found ? "найден " : "не найден ") << value << endl;
  } else if (command == "LPUSH") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды LPUSH\n";
      return;
    }
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    list.pushBack(value);
    saveDoublyListToFile(filename, list);
    cout << "-> добавлен " << value << endl;
  } else if (command == "LDEL") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды LDEL\n";
      return;
    }
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    bool ok = list.delByValue(value);
    saveDoublyListToFile(filename, list);
    if (ok) {
      cout << "-> удалён " << value << endl;
    } else {
      cout << "-> элемент " << value << " не найден" << endl;
    }
  } else if (command == "LGET") {
    int index;
    if (!(iss >> index)) {
      cerr << "Ошибка: неверный формат команды LGET\n";
      return;
    }
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    cout << "-> " << list.get(index) << endl;
  } else if (command == "PRINTL") {
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    cout << "-> ";
    list.print();
  } else if (command == "LPUSHFRONT") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды LPUSHFRONT\n";
      return;
    }
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    list.pushFront(value);
    saveDoublyListToFile(filename, list);
    cout << "-> добавлен " << value << " в голову" << endl;
  } else if (command == "LINSERTBEFORE") {
    int target, value;
    if (!(iss >> target >> value)) {
      cerr << "Ошибка: неверный формат команды LINSERTBEFORE\n";
      return;
    }
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    list.insertBefore(target, value);
    saveDoublyListToFile(filename, list);
    cout << "-> вставлен " << value << " перед " << target << endl;
  } else if (command == "LINSERTAFTER") {
    int target, value;
    if (!(iss >> target >> value)) {
      cerr << "Ошибка: неверный формат команды LINSERTAFTER\n";
      return;
    }
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    list.insertAfter(target, value);
    saveDoublyListToFile(filename, list);
    cout << "-> вставлен " << value << " после " << target << endl;
  } else if (command == "LCONTAINS") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды LCONTAINS\n";
      return;
    }
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    bool found = list.contains(value);
    cout << "-> " << (found ? "найден " : "не найден ") << value << endl;
  } else if (command == "LDELFRONT") {
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    bool ok = list.delFront();
    saveDoublyListToFile(filename, list);
    if (ok) {
      cout << "-> удалён первый элемент" << endl;
    } else {
      cout << "Ошибка: список пуст" << endl;
    }
  } else if (command == "LDELBACK") {
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    bool ok = list.delBack();
    saveDoublyListToFile(filename, list);
    if (ok) {
      cout << "-> удалён последний элемент" << endl;
    } else {
      cout << "Ошибка: список пуст" << endl;
    }
  } else if (command == "SPUSH") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды SPUSH\n";
      return;
    }
    Stack stack;
    loadStackFromFile(filename, stack);
    stack.push(value);
    saveStackToFile(filename, stack);
    cout << "-> добавлен " << value << endl;
  } else if (command == "SPOP") {
    Stack stack;
    loadStackFromFile(filename, stack);
    if (!stack.empty()) {
      int value = stack.top();
      stack.pop();
      saveStackToFile(filename, stack);
      cout << "-> удалён верхний элемент " << value << endl;
    } else {
      cout << "Ошибка: стек пуст" << endl;
    }
  } else if (command == "PRINTS") {
    Stack stack;
    loadStackFromFile(filename, stack);
    cout << "-> ";
    stack.print();
  } else if (command == "QPUSH") {
    int value;
    if (!(iss >> value)) {
      cerr << "Ошибка: неверный формат команды QPUSH\n";
      return;
    }
    Queue queue;
    loadQueueFromFile(filename, queue);
    queue.push(value);
    saveQueueToFile(filename, queue);
    cout << "-> добавлен " << value << endl;
  } else if (command == "QPOP") {
    Queue queue;
    loadQueueFromFile(filename, queue);
    if (!queue.empty()) {
      int value = queue.front();
      queue.pop();
      saveQueueToFile(filename, queue);
      cout << "-> удалён первый элемент " << value << endl;
    } else {
      cout << "Ошибка: очередь пуста" << endl;
    }
  } else if (command == "PRINTQ") {
    Queue queue;
    loadQueueFromFile(filename, queue);
    cout << "-> ";
    queue.print();
  } else if (command == "SETDOUBLEHASH") {
    hashTable = HashTable(11, HashType::OPEN_ADDRESSING);
    saveHashToFile(filename, hashTable);
    cout << "Режим: Двойное хеширование.\n";
    return;
  } else if (command == "SETCUCKOOHASH") {
    hashTable = HashTable(11, HashType::SEPARATE_CHAINING);
    saveHashToFile(filename, hashTable);
    cout << "Режим: Кукушкино хеширование.\n";
    return;
  } else if (command == "SETFOLDHASH") {
    hashTable = HashTable(11, HashType::FOLDING_HASHING);
    cout << "Режим: Метод свёртки (Folding hashing)." << endl;
    saveHashToFile(filename, hashTable);
    return;
  } else if (command == "HASHADD") {
    size_t pos = query.find(command);
    string rest = (pos != string::npos) ? ltrim(query.substr(pos + command.size())) : string();
    istringstream args(rest);
    int key, value;
    if (!(args >> key >> value)) {
      cerr << "Ошибка: команда должна быть вида HASHADD <key> <value>\n";
      return;
    }

    loadHashFromFile(filename, hashTable);
    hashTable.insert(key, value);
    saveHashToFile(filename, hashTable);
    cout << "Элемент (" << key << ", " << value << ") добавлен в хеш-таблицу и сохранён в файл.\n";
    return;
  } else if (command == "HASHDEL") {
    size_t pos = query.find(command);
    string rest = (pos != string::npos) ? ltrim(query.substr(pos + command.size())) : string();
    istringstream args(rest);
    int key;
    if (!(args >> key)) {
      cerr << "Ошибка: команда должна быть вида HASHDEL <key>\n";
      return;
    }

    loadHashFromFile(filename, hashTable);
    bool removed = hashTable.remove(key);
    if (!removed) {
      cout << "Ключ " << key << " не найден.\n";
      return;
    }

    saveHashToFile(filename, hashTable);
    cout << "Ключ " << key << " удалён из таблицы и файла.\n";
    return;
  } else if (command == "HASHGET") {
    size_t pos = query.find(command);
    string rest = (pos != string::npos) ? ltrim(query.substr(pos + command.size())) : string();
    istringstream args(rest);
    int key;
    if (!(args >> key)) {
      cerr << "Ошибка: команда должна быть вида HASHGET <key>\n";
      return;
    }

    loadHashFromFile(filename, hashTable);
    auto res = hashTable.get(key);
    if (res.has_value()) {
      cout << "Значение для ключа " << key << ": " << res.value() << "\n";
    } else {
      cout << "Ключ " << key << " не найден.\n";
    }
    return;
  } else if (command == "PRINTHASH") {
    loadHashFromFile(filename, hashTable);
    string mode;
    switch (hashTable.getType()) {
    case HashType::OPEN_ADDRESSING:
      mode = "Double hashing";
      break;
    case HashType::SEPARATE_CHAINING:
      mode = "Cuckoo hashing";
      break;
    case HashType::FOLDING_HASHING:
      mode = "Folding hashing (метод свёртки)";
      break;
    }

    cout << "Текущий режим: " << mode << "\n";
    hashTable.print();
    return;
  } else if (command == "ARRAY_SAVE_BIN") {
    Array arr;
    loadArrayFromFile(filename, arr);
    saveArrayToBinaryFile(filename + ".bin", arr);
    cout << "Массив сохранен в бинарном формате: " << filename + ".bin" << endl;
  } else if (command == "ARRAY_LOAD_BIN") {
    Array arr;
    loadArrayFromBinaryFile(filename, arr);
    saveArrayToFile(filename, arr);
    cout << "Массив загружен из бинарного формата: " << filename << endl;
  } else if (command == "SLIST_SAVE_BIN") {
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    saveListToBinaryFile(filename + ".bin", list);
    cout << "Односвязный список сохранен в бинарном формате: " << filename + ".bin" << endl;
  } else if (command == "SLIST_LOAD_BIN") {
    SinglyLinkedList list;
    loadListFromBinaryFile(filename, list);
    saveListToFile(filename, list);
    cout << "Односвязный список загружен из бинарного формата: " << filename << endl;
  } else if (command == "DLIST_SAVE_BIN") {
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    saveDoublyListToBinaryFile(filename + ".bin", list);
    cout << "Двусвязный список сохранен в бинарном формате: " << filename + ".bin" << endl;
  } else if (command == "DLIST_LOAD_BIN") {
    DoublyLinkedList list;
    loadDoublyListFromBinaryFile(filename, list);
    saveDoublyListToFile(filename, list);
    cout << "Двусвязный список загружен из бинарного формата: " << filename << endl;
  } else if (command == "STACK_SAVE_BIN") {
    Stack stack;
    loadStackFromFile(filename, stack);
    saveStackToBinaryFile(filename + ".bin", stack);
    cout << "Стек сохранен в бинарном формате: " << filename + ".bin" << endl;
  } else if (command == "STACK_LOAD_BIN") {
    Stack stack;
    loadStackFromBinaryFile(filename, stack);
    saveStackToFile(filename, stack);
    cout << "Стек загружен из бинарного формата: " << filename << endl;
  } else if (command == "QUEUE_SAVE_BIN") {
    Queue queue;
    loadQueueFromFile(filename, queue);
    saveQueueToBinaryFile(filename + ".bin", queue);
    cout << "Очередь сохранена в бинарном формате: " << filename + ".bin" << endl;
  } else if (command == "QUEUE_LOAD_BIN") {
    Queue queue;
    loadQueueFromBinaryFile(filename, queue);
    saveQueueToFile(filename, queue);
    cout << "Очередь загружена из бинарного формата: " << filename << endl;
  } else if (command == "TREE_SAVE_BIN") {
    CompleteBinaryTree tree;
    loadTreeFromFile(filename, tree);
    saveTreeToBinaryFile(filename + ".bin", tree);
    cout << "Дерево сохранено в бинарном формате: " << filename + ".bin" << endl;
  } else if (command == "TREE_LOAD_BIN") {
    CompleteBinaryTree tree;
    loadTreeFromBinaryFile(filename, tree);
    saveTreeToFile(filename, tree);
    cout << "Дерево загружено из бинарного формата: " << filename << endl;
  } else if (command == "HASH_SAVE_BIN") {
    HashTable ht;
    loadHashFromFile(filename, ht);
    saveHashToBinaryFile(filename + ".bin", ht);
    cout << "Хеш-таблица сохранена в бинарном формате: " << filename + ".bin" << endl;
  } else if (command == "HASH_LOAD_BIN") {
    HashTable ht;
    loadHashFromBinaryFile(filename, ht);
    saveHashToFile(filename, ht);
    cout << "Хеш-таблица загружена из бинарного формата: " << filename << endl;
  } else if (command == "ARRAY_SAVE_TXT") {
    Array arr;
    loadArrayFromFile(filename, arr);
    ofstream fout(filename + ".txt");
    arr.serializeText(fout);
    cout << "Массив сохранен в текстовом формате: " << filename + ".txt" << endl;
  } else if (command == "ARRAY_LOAD_TXT") {
    Array arr;
    ifstream fin(filename);
    arr.deserializeText(fin);
    saveArrayToFile(filename, arr);
    cout << "Массив загружен из текстового формата: " << filename << endl;
  } else if (command == "SLIST_SAVE_TXT") {
    SinglyLinkedList list;
    loadListFromFile(filename, list);
    ofstream fout(filename + ".txt");
    list.serializeText(fout);
    cout << "Односвязный список сохранен в текстовом формате: " << filename + ".txt" << endl;
  } else if (command == "SLIST_LOAD_TXT") {
    SinglyLinkedList list;
    ifstream fin(filename);
    list.deserializeText(fin);
    saveListToFile(filename, list);
    cout << "Односвязный список загружен из текстового формата: " << filename << endl;
  } else if (command == "DLIST_SAVE_TXT") {
    DoublyLinkedList list;
    loadDoublyListFromFile(filename, list);
    ofstream fout(filename + ".txt");
    list.serializeText(fout);
    cout << "Двусвязный список сохранен в текстовом формате: " << filename + ".txt" << endl;
  } else if (command == "DLIST_LOAD_TXT") {
    DoublyLinkedList list;
    ifstream fin(filename);
    list.deserializeText(fin);
    saveDoublyListToFile(filename, list);
    cout << "Двусвязный список загружен из текстового формата: " << filename << endl;
  } else if (command == "STACK_SAVE_TXT") {
    Stack stack;
    loadStackFromFile(filename, stack);
    ofstream fout(filename + ".txt");
    stack.serializeText(fout);
    cout << "Стек сохранен в текстовом формате: " << filename + ".txt" << endl;
  } else if (command == "STACK_LOAD_TXT") {
    Stack stack;
    ifstream fin(filename);
    stack.deserializeText(fin);
    saveStackToFile(filename, stack);
    cout << "Стек загружен из текстового формата: " << filename << endl;
  } else if (command == "QUEUE_SAVE_TXT") {
    Queue queue;
    loadQueueFromFile(filename, queue);
    ofstream fout(filename + ".txt");
    queue.serializeText(fout);
    cout << "Очередь сохранена в текстовом формате: " << filename + ".txt" << endl;
  } else if (command == "QUEUE_LOAD_TXT") {
    Queue queue;
    ifstream fin(filename);
    queue.deserializeText(fin);
    saveQueueToFile(filename, queue);
    cout << "Очередь загружена из текстового формата: " << filename << endl;
  } else if (command == "TREE_SAVE_TXT") {
    CompleteBinaryTree tree;
    loadTreeFromFile(filename, tree);
    ofstream fout(filename + ".txt");
    tree.serializeText(fout);
    cout << "Дерево сохранено в текстовом формате: " << filename + ".txt" << endl;
  } else if (command == "TREE_LOAD_TXT") {
    CompleteBinaryTree tree;
    ifstream fin(filename);
    tree.deserializeText(fin);
    saveTreeToFile(filename, tree);
    cout << "Дерево загружено из текстового формата: " << filename << endl;
  } else if (command == "HASH_SAVE_TXT") {
    HashTable ht;
    loadHashFromFile(filename, ht);
    ofstream fout(filename + ".txt");
    ht.serializeText(fout);
    cout << "Хеш-таблица сохранена в текстовом формате: " << filename + ".txt" << endl;
  } else if (command == "HASH_LOAD_TXT") {
    HashTable ht;
    ifstream fin(filename);
    ht.deserializeText(fin);
    saveHashToFile(filename, ht);
    cout << "Хеш-таблица загружена из текстового формата: " << filename << endl;
  } else {
    cerr << "Неизвестная команда: " << command << endl;
  }
}