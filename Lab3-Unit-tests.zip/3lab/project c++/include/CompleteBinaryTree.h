#pragma once
#include <algorithm>
#include <iostream>
#include <queue>
#include <string>
#include <vector>

struct CBTNode {
  int data;
  CBTNode *left;
  CBTNode *right;
  CBTNode *parent;

  explicit CBTNode(int val)
      : data(val), left(nullptr), right(nullptr), parent(nullptr) {}
};

class CompleteBinaryTree {
private:
  CBTNode *root;
  int nodeCount;

  // Вспомогательные функции
  CBTNode *getLastNode() const;
  CBTNode *getParentOfNextInsertion() const;
  void updateParentPointers(CBTNode *node, CBTNode *parent);
  static void deleteTree(CBTNode *node); // Сделано static
  CBTNode *findNode(int value) const;
  static CBTNode *findNodeHelper(CBTNode *node, int value); // Сделано static
  static int getHeight(CBTNode *node); // Сделано static
  bool isCompleteHelper(CBTNode *node, int index, int count) const;
  static void inorderHelper(CBTNode *node,
                            std::vector<int> &result); // Сделано static
  static void preorderHelper(CBTNode *node,
                             std::vector<int> &result); // Сделано static
  static void postorderHelper(CBTNode *node,
                              std::vector<int> &result); // Сделано static
  void levelOrderHelper(std::vector<int> &result) const;
  static std::string getNodeInfo(const CBTNode *node);

  // Вспомогательные функции для копирования
  static CBTNode *copyTree(CBTNode *node, CBTNode *parent); // Сделано static

public:
  CompleteBinaryTree();
  ~CompleteBinaryTree();
  CompleteBinaryTree(const CompleteBinaryTree &other);
  CompleteBinaryTree &operator=(const CompleteBinaryTree &other);

  // Основные операции
  void insert(int value);
  bool remove(int value);
  bool contains(int value) const;

  // Обходы
  std::vector<int> inorder() const;
  std::vector<int> preorder() const;
  std::vector<int> postorder() const;
  std::vector<int> levelOrder() const;

  // Информация о дереве
  int size() const { return nodeCount; }
  bool empty() const { return root == nullptr; }
  int height() const;
  bool isComplete() const;
  bool isPerfect() const;

  // Валидация и вывод
  bool validate() const;
  void print() const;
  void printTree() const;

  // Сериализация
  void serializeBinary(std::ostream &os) const;
  void deserializeBinary(std::istream &is);
  void serializeText(std::ostream &os) const;
  void deserializeText(std::istream &is);
};