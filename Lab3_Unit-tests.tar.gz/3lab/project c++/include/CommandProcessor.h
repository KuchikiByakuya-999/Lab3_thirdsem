#pragma once
#include <string>

class CommandProcessor {
public:
  static void execute(const std::string &query, const std::string &filename);
};