#include <gtest/gtest.h>
#include "../include/SinglyLinkedList.h"

class SinglyLinkedListTest : public ::testing::Test {
protected:
    void SetUp() override {
        list.pushBack(1);
        list.pushBack(2);
        list.pushBack(3);
    }

    SinglyLinkedList list;
};

TEST_F(SinglyLinkedListTest, InitialSize) {
    auto vec = list.toVector();
    EXPECT_EQ(vec.size(), 3);
}

TEST_F(SinglyLinkedListTest, PushFront) {
    list.pushFront(0);
    auto vec = list.toVector();
    EXPECT_EQ(vec[0], 0);
    EXPECT_EQ(vec.size(), 4);
}

TEST_F(SinglyLinkedListTest, PushBack) {
    list.pushBack(4);
    auto vec = list.toVector();
    EXPECT_EQ(vec[3], 4);
    EXPECT_EQ(vec.size(), 4);
}

TEST_F(SinglyLinkedListTest, Contains) {
    EXPECT_TRUE(list.contains(2));
    EXPECT_FALSE(list.contains(99));
}

TEST_F(SinglyLinkedListTest, DeleteByValue) {
    bool removed = list.delByValue(2);
    EXPECT_TRUE(removed);
    EXPECT_FALSE(list.contains(2));

    removed = list.delByValue(99);
    EXPECT_FALSE(removed);
}

TEST_F(SinglyLinkedListTest, InsertBefore) {
    list.insertBefore(2, 99);
    auto vec = list.toVector();
    EXPECT_EQ(vec[1], 99);
}

TEST_F(SinglyLinkedListTest, InsertAfter) {
    list.insertAfter(2, 99);
    auto vec = list.toVector();
    EXPECT_EQ(vec[2], 99);
}

// Добавить в существующий класс SinglyLinkedListTest

TEST_F(SinglyLinkedListTest, AdvancedInsertOperations) {
    // Сложные операции вставки
    list.insertBefore(2, 99);
    list.insertAfter(2, 88);
    
    auto vec = list.toVector();
    EXPECT_EQ(vec.size(), 5);
    EXPECT_EQ(vec[1], 99);
    EXPECT_EQ(vec[3], 88);
}

TEST_F(SinglyLinkedListTest, DeleteOperations) {
    // Удаление первого и последнего
    EXPECT_TRUE(list.delFront());
    auto vec = list.toVector();
    EXPECT_EQ(vec.size(), 2);
    EXPECT_EQ(vec[0], 2);
    
    EXPECT_TRUE(list.delBack());
    vec = list.toVector();
    EXPECT_EQ(vec.size(), 1);
    EXPECT_EQ(vec[0], 2);
}

TEST_F(SinglyLinkedListTest, EdgeCases) {
    SinglyLinkedList emptyList;
    
    // Операции на пустом списке
    EXPECT_FALSE(emptyList.delFront());
    EXPECT_FALSE(emptyList.delBack());
    EXPECT_FALSE(emptyList.contains(1));
    EXPECT_EQ(emptyList.get(0), -1);

}

TEST_F(SinglyLinkedListTest, Serialization) {
    // Тестируем сериализацию
    std::stringstream ss_bin;
    list.serializeBinary(ss_bin);
    
    SinglyLinkedList list2;
    list2.deserializeBinary(ss_bin);
    
    auto vec1 = list.toVector();
    auto vec2 = list2.toVector();
    EXPECT_EQ(vec1, vec2);
    
    // Текстовая сериализация
    std::stringstream ss_text;
    list.serializeText(ss_text);
    
    SinglyLinkedList list3;
    list3.deserializeText(ss_text);
    
    auto vec3 = list3.toVector();
    EXPECT_EQ(vec1, vec3);
}

TEST_F(SinglyLinkedListTest, ComplexScenarios) {
    // Комплексные сценарии
    list.pushFront(0);
    list.pushBack(4);
    list.insertBefore(2, 99);
    list.insertAfter(2, 88);
    
    EXPECT_TRUE(list.delByValue(99));
    EXPECT_TRUE(list.delByValue(88));
    
    auto vec = list.toVector();
    EXPECT_EQ(vec.size(), 5);
    EXPECT_EQ(vec[0], 0);
    EXPECT_EQ(vec[4], 4);
}