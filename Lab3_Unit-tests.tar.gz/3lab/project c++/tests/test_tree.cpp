#include <gtest/gtest.h>
#include "../include/CompleteBinaryTree.h"

class CompleteBinaryTreeTest : public ::testing::Test {
protected:
    void SetUp() override {
        tree.insert(1);
        tree.insert(2);
        tree.insert(3);
        tree.insert(4);
        tree.insert(5);
    }

    CompleteBinaryTree tree;
};

TEST_F(CompleteBinaryTreeTest, InsertAndContains) {
    EXPECT_TRUE(tree.contains(1));
    EXPECT_TRUE(tree.contains(3));
    EXPECT_TRUE(tree.contains(5));
    EXPECT_FALSE(tree.contains(99));
}

TEST_F(CompleteBinaryTreeTest, Remove) {
    EXPECT_TRUE(tree.remove(3));
    EXPECT_FALSE(tree.contains(3));
    EXPECT_TRUE(tree.validate());
}

TEST_F(CompleteBinaryTreeTest, ValidateTree) {
    EXPECT_TRUE(tree.validate());
    EXPECT_TRUE(tree.isComplete());
}

TEST_F(CompleteBinaryTreeTest, Traversals) {
    auto inorder = tree.inorder();
    auto preorder = tree.preorder();
    auto postorder = tree.postorder();
    auto levelorder = tree.levelOrder();
    
    EXPECT_EQ(inorder.size(), 5);
    EXPECT_EQ(preorder.size(), 5);
    EXPECT_EQ(postorder.size(), 5);
    EXPECT_EQ(levelorder.size(), 5);
}

TEST_F(CompleteBinaryTreeTest, EmptyTree) {
    CompleteBinaryTree emptyTree;
    EXPECT_TRUE(emptyTree.empty());
    EXPECT_FALSE(emptyTree.contains(1));
    EXPECT_TRUE(emptyTree.validate());
}

TEST_F(CompleteBinaryTreeTest, SizeAndHeight) {
    EXPECT_EQ(tree.size(), 5);
    EXPECT_GT(tree.height(), 0);
}

TEST_F(CompleteBinaryTreeTest, MultipleOperations) {
    CompleteBinaryTree testTree;
    
    for (int i = 1; i <= 10; i++) {
        testTree.insert(i);
    }
    
    EXPECT_TRUE(testTree.validate());
    EXPECT_EQ(testTree.size(), 10);
    
    // Удаляем несколько элементов
    testTree.remove(5);
    testTree.remove(8);
    
    EXPECT_EQ(testTree.size(), 8);
    EXPECT_FALSE(testTree.contains(5));
    EXPECT_FALSE(testTree.contains(8));
    EXPECT_TRUE(testTree.validate());
}

// Добавить в существующий класс CompleteBinaryTreeTest

TEST_F(CompleteBinaryTreeTest, AdvancedOperations) {
    // Сложные операции
    for (int i = 6; i <= 10; i++) {
        tree.insert(i);
    }
    
    EXPECT_TRUE(tree.validate());
    EXPECT_EQ(tree.size(), 10);
    
    // Удаление нескольких элементов
    EXPECT_TRUE(tree.remove(3));
    EXPECT_TRUE(tree.remove(7));
    EXPECT_FALSE(tree.contains(3));
    EXPECT_FALSE(tree.contains(7));
    EXPECT_TRUE(tree.validate());
}

TEST_F(CompleteBinaryTreeTest, TraversalConsistency) {
    // Проверка согласованности обходов
    auto inorder = tree.inorder();
    auto preorder = tree.preorder();
    auto postorder = tree.postorder();
    auto levelorder = tree.levelOrder();
    
    // Все обходы должны содержать одинаковые элементы
    std::set<int> inorder_set(inorder.begin(), inorder.end());
    std::set<int> preorder_set(preorder.begin(), preorder.end());
    std::set<int> postorder_set(postorder.begin(), postorder.end());
    std::set<int> levelorder_set(levelorder.begin(), levelorder.end());
    
    EXPECT_EQ(inorder_set, preorder_set);
    EXPECT_EQ(preorder_set, postorder_set);
    EXPECT_EQ(postorder_set, levelorder_set);
}

TEST_F(CompleteBinaryTreeTest, CopyAndAssignment) {
    // Тестируем конструктор копирования и оператор присваивания
    CompleteBinaryTree copyTree(tree);
    EXPECT_EQ(copyTree.size(), tree.size());
    EXPECT_TRUE(copyTree.validate());
    
    CompleteBinaryTree assignedTree;
    assignedTree = tree;
    EXPECT_EQ(assignedTree.size(), tree.size());
    EXPECT_TRUE(assignedTree.validate());
    
    // Проверяем что это глубокие копии
    tree.insert(100);
    EXPECT_FALSE(copyTree.contains(100));
    EXPECT_FALSE(assignedTree.contains(100));
}

TEST_F(CompleteBinaryTreeTest, Serialization) {
    // Тестируем сериализацию
    std::stringstream ss_bin;
    tree.serializeBinary(ss_bin);
    
    CompleteBinaryTree tree2;
    tree2.deserializeBinary(ss_bin);
    
    EXPECT_EQ(tree2.size(), tree.size());
    EXPECT_TRUE(tree2.validate());
    
    // Текстовая сериализация
    std::stringstream ss_text;
    tree.serializeText(ss_text);
    
    CompleteBinaryTree tree3;
    tree3.deserializeText(ss_text);
    
    EXPECT_EQ(tree3.size(), tree.size());
    EXPECT_TRUE(tree3.validate());
}

TEST_F(CompleteBinaryTreeTest, LargeDataset) {
    CompleteBinaryTree largeTree;
    
    // Вставляем много элементов
    for (int i = 1; i <= 50; i++) {
        largeTree.insert(i);
    }
    
    EXPECT_TRUE(largeTree.validate());
    EXPECT_EQ(largeTree.size(), 50);
    
    // Удаляем только несколько элементов, которые точно существуют
    EXPECT_TRUE(largeTree.remove(10));
    EXPECT_TRUE(largeTree.remove(20));
    EXPECT_TRUE(largeTree.remove(30));
    EXPECT_TRUE(largeTree.remove(40));
    EXPECT_TRUE(largeTree.remove(50));
    
    EXPECT_TRUE(largeTree.validate());
    EXPECT_EQ(largeTree.size(), 45);
    
    // Проверяем что удаленные элементы отсутствуют
    EXPECT_FALSE(largeTree.contains(10));
    EXPECT_FALSE(largeTree.contains(20));
    EXPECT_FALSE(largeTree.contains(30));
    EXPECT_FALSE(largeTree.contains(40));
    EXPECT_FALSE(largeTree.contains(50));
    
    // Проверяем что остальные присутствуют
    EXPECT_TRUE(largeTree.contains(1));
    EXPECT_TRUE(largeTree.contains(25));
    EXPECT_TRUE(largeTree.contains(49));
}