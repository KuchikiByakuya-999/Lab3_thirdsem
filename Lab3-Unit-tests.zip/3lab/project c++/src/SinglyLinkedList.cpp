#include "../include/SinglyLinkedList.h"

SinglyLinkedList::SinglyLinkedList() : head(nullptr) {}

SinglyLinkedList::~SinglyLinkedList() {
  while (head != nullptr) {
    FNode *tmp = head;
    head = head->next;
    delete tmp;
  }
}

void SinglyLinkedList::pushFront(int value) {
  FNode *node = new FNode(value);
  node->next = head;
  head = node;
}

void SinglyLinkedList::pushBack(int value) {
  FNode *node = new FNode(value);
  if (head == nullptr) {
    head = node;
    return;
  }
  FNode *curr = head;
  while (curr->next != nullptr) {
    curr = curr->next;
  }
  curr->next = node;
}

bool SinglyLinkedList::delByValue(int value) {
  if (head == nullptr) {
    return false;
  }

  if (head->data == value) {
    FNode *tmp = head;
    head = head->next;
    delete tmp;
    return true;
  }

  FNode *curr = head;
  while (curr->next != nullptr && curr->next->data != value) {
    curr = curr->next;
  }
  if (curr->next == nullptr) {
    return false;
  }

  FNode *tmp = curr->next;
  curr->next = tmp->next;
  delete tmp;
  return true;
}

int SinglyLinkedList::get(int index) const { // Добавлен const
  FNode *curr = head;
  int i = 0;
  while (curr != nullptr) {
    if (i == index) {
      return curr->data;
    }
    curr = curr->next;
    i++;
  }
  std::cerr << "Ошибка: индекс вне диапазона\n";
  return -1;
}

void SinglyLinkedList::print() const {
  FNode *curr = head;
  while (curr != nullptr) {
    std::cout << curr->data << " ";
    curr = curr->next;
  }
  std::cout << std::endl;
}

std::vector<int> SinglyLinkedList::toVector() const {
  std::vector<int> result;
  FNode *curr = head;
  while (curr != nullptr) {
    result.push_back(curr->data);
    curr = curr->next;
  }
  return result;
}

void SinglyLinkedList::insertBefore(int target, int value) {
  if (head == nullptr) {
    return;
  }

  if (head->data == target) {
    pushFront(value);
    return;
  }

  FNode *curr = head;
  while (curr->next != nullptr && curr->next->data != target) {
    curr = curr->next;
  }
  if (curr->next == nullptr) {
    return;
  }

  FNode *node = new FNode(value);
  node->next = curr->next;
  curr->next = node;
}

void SinglyLinkedList::insertAfter(int target,
                                   int value) const { // Добавлен const
  FNode *curr = head;
  while (curr != nullptr && curr->data != target) {
    curr = curr->next;
  }
  if (curr == nullptr) {
    return;
  }

  FNode *node = new FNode(value);
  node->next = curr->next;
  curr->next = node;
}

bool SinglyLinkedList::contains(int value) const {
  FNode *curr = head;
  while (curr != nullptr) {
    if (curr->data == value) {
      return true;
    }
    curr = curr->next;
  }
  return false;
}

bool SinglyLinkedList::delFront() {
  if (head == nullptr) {
    std::cerr << "Ошибка: список пуст\n";
    return false;
  }
  FNode *tmp = head;
  head = head->next;
  delete tmp;
  return true;
}

bool SinglyLinkedList::delBack() {
  if (head == nullptr) {
    std::cerr << "Ошибка: список пуст\n";
    return false;
  }
  if (head->next == nullptr) {
    delete head;
    head = nullptr;
    return true;
  }
  FNode *curr = head;
  while (curr->next->next != nullptr) {
    curr = curr->next;
  }
  delete curr->next;
  curr->next = nullptr;
  return true;
}

void SinglyLinkedList::serializeBinary(std::ostream &os) const {
  std::vector<int> vec = toVector();
  size_t vec_size = vec.size();
  os.write(reinterpret_cast<const char *>(&vec_size), sizeof(vec_size));
  if (vec_size > 0) {
    os.write(reinterpret_cast<const char *>(vec.data()),
             vec_size * sizeof(int));
  }
}

void SinglyLinkedList::deserializeBinary(std::istream &is) {
  while (head != nullptr) {
    FNode *tmp = head;
    head = head->next;
    delete tmp;
  }

  size_t vec_size;
  is.read(reinterpret_cast<char *>(&vec_size), sizeof(vec_size));

  if (vec_size > 0) {
    std::vector<int> temp(vec_size);
    is.read(reinterpret_cast<char *>(temp.data()), vec_size * sizeof(int));

    for (int value : temp) {
      pushBack(value);
    }
  }
}

void SinglyLinkedList::serializeText(std::ostream &os) const {
  std::vector<int> vec = toVector();
  for (size_t i = 0; i < vec.size(); ++i) {
    os << vec[i];
    if (i < vec.size() - 1) {
      os << " ";
    }
  }
}

void SinglyLinkedList::deserializeText(std::istream &is) {
  while (head != nullptr) {
    FNode *tmp = head;
    head = head->next;
    delete tmp;
  }

  int value;
  while (is >> value) {
    pushBack(value);
  }
}