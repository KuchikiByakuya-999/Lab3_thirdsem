#include <gtest/gtest.h>
#include "../include/CommandProcessor.h"
#include "../include/Array.h"
#include "../include/SinglyLinkedList.h"
#include "../include/DoublyLinkedList.h"
#include "../include/Stack.h"
#include "../include/Queue.h"
#include "../include/CompleteBinaryTree.h"
#include "../include/HashTable.h"

#include <fstream>
#include <sstream>
#include <filesystem>
#include <vector>
#include <string>
#include <algorithm>
#include <cstdlib>

class CommandProcessorTest : public ::testing::Test {
protected:
    std::vector<std::string> test_files_to_cleanup;

    void SetUp() override {
        test_files_to_cleanup.clear();
        
        // Создаем тестовые файлы
        std::vector<std::pair<std::string, std::string>> test_files = {
            {"test_array.txt", "1 2 3 4 5"},
            {"test_list.txt", "10 20 30"},
            {"test_tree.txt", "5 3 7 1 9"},
            {"test_stack.txt", "100 200 300"},
            {"test_queue.txt", "50 60 70"},
            {"test_hash.txt", "TYPE DOUBLE\nSIZE 11\n1 100\n2 200\n3 300"}
        };

        for (const auto& [filename, content] : test_files) {
            std::ofstream file(filename);
            file << content;
            file.close();
            test_files_to_cleanup.push_back(filename);
        }
    }

    void TearDown() override {
        // Удаляем все созданные тестовые файлы
        for (const auto& file : test_files_to_cleanup) {
            if (std::filesystem::exists(file)) {
                std::filesystem::remove(file);
            }
        }
        
        // Дополнительные файлы, которые могли быть созданы
        std::vector<std::string> additional_files = {
            "test_array.bin", "test_list.bin", "test_tree.bin",
            "test_stack.bin", "test_queue.bin", "test_hash.bin",
            "test_tree.txt.bin", "test_tree.bin", "empty.txt",
            "corrupt.txt", "test file with spaces.txt",
            "multi1.txt", "multi2.txt", "multi3.txt",
            "weird_delimiter.txt", "binary_data.txt",
            "very_long_filename_that_exceeds_normal_length_but_still_should_work_properly_with_the_system.txt",
            "unicode_test.txt", "original.txt", "symlink.txt",
            "array_bin.bin", "slist_bin.bin", "dlist_bin.bin",
            "stack_bin.bin", "queue_bin.bin", "tree_bin.bin", "hash_bin.bin",
            "array_txt.txt", "slist_txt.txt", "dlist_txt.txt",
            "stack_txt.txt", "queue_txt.txt", "tree_txt.txt", "hash_txt.txt",
            "array_loaded.txt", "slist_loaded.txt", "dlist_loaded.txt",
            "stack_loaded.txt", "queue_loaded.txt", "tree_loaded.txt", "hash_loaded.txt",
            "array_txt_loaded.txt", "slist_txt_loaded.txt", "dlist_txt_loaded.txt",
            "stack_txt_loaded.txt", "queue_txt_loaded.txt", "tree_txt_loaded.txt", "hash_txt_loaded.txt",
            "test_array_new.txt", "test_tree_new.txt", "empty_tree.txt", "single_node.txt"
        };
        
        for (const auto& file : additional_files) {
            if (std::filesystem::exists(file)) {
                std::filesystem::remove(file);
            }
        }

        // Удаляем тестовую директорию если существует
        std::string subdir = "test_subdir";
        if (std::filesystem::exists(subdir)) {
            std::filesystem::remove_all(subdir);
        }
    }

    // Вспомогательная функция для регистрации файлов для очистки
    void registerFileForCleanup(const std::string& filename) {
        test_files_to_cleanup.push_back(filename);
    }

    // Вспомогательные функции для проверки состояния
    bool treeContainsValue(const std::string& filename, int value) {
        CompleteBinaryTree tree;
        std::ifstream fin(filename);
        int val;
        while (fin >> val) {
            tree.insert(val);
        }
        fin.close();
        return tree.contains(value);
    }

    std::vector<int> readArrayFromFile(const std::string& filename) {
        std::vector<int> result;
        std::ifstream fin(filename);
        int value;
        while (fin >> value) {
            result.push_back(value);
        }
        fin.close();
        return result;
    }

    bool fileExists(const std::string& filename) {
        return std::filesystem::exists(filename);
    }
};

// Тесты для Complete Binary Tree
TEST_F(CommandProcessorTest, CBTInsertCommand) {
    CommandProcessor::execute("CBTINSERT 15 test_tree.txt", "test_tree.txt");
    
    EXPECT_TRUE(treeContainsValue("test_tree.txt", 15));
}

TEST_F(CommandProcessorTest, CBTDeleteCommand) {
    // Сначала добавляем элемент
    CommandProcessor::execute("CBTINSERT 25 test_tree.txt", "test_tree.txt");
    
    // Затем удаляем его
    CommandProcessor::execute("CBTDEL 25 test_tree.txt", "test_tree.txt");
    
    EXPECT_FALSE(treeContainsValue("test_tree.txt", 25));
}

TEST_F(CommandProcessorTest, CBTGetCommand) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("CBTGET 5 test_tree.txt", "test_tree.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    EXPECT_TRUE(output.find("TRUE") != std::string::npos);
}

TEST_F(CommandProcessorTest, CBTValidateCommand) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("CBTVALIDATE test_tree.txt", "test_tree.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    EXPECT_TRUE(output.find("Complete Binary Tree Validation") != std::string::npos);
}

TEST_F(CommandProcessorTest, CBTPrintCommand) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("CBTPRINT test_tree.txt", "test_tree.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    EXPECT_FALSE(output.empty());
    EXPECT_TRUE(output.find("Level Order") != std::string::npos);
}

TEST_F(CommandProcessorTest, CBTPrintTreeCommand) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("CBTPRINT_TREE test_tree.txt", "test_tree.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    EXPECT_FALSE(output.empty());
}

// Тесты для Array
TEST_F(CommandProcessorTest, ArrayPushCommand) {
    CommandProcessor::execute("MPUSH 99 test_array.txt", "test_array.txt");
    
    auto values = readArrayFromFile("test_array.txt");
    EXPECT_NE(std::find(values.begin(), values.end(), 99), values.end());
}

TEST_F(CommandProcessorTest, ArrayDeleteCommand) {
    CommandProcessor::execute("MDEL 2 test_array.txt", "test_array.txt");
    
    auto values = readArrayFromFile("test_array.txt");
    EXPECT_EQ(values.size(), 4); // Было 5 элементов, один удалили
}

TEST_F(CommandProcessorTest, ArrayGetCommand) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("MGET 0 test_array.txt", "test_array.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    EXPECT_TRUE(output.find("1") != std::string::npos); // Первый элемент должен быть 1
}

TEST_F(CommandProcessorTest, ArrayPrintCommand) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("PRINTM test_array.txt", "test_array.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    EXPECT_FALSE(output.empty());
}

// Тесты для Singly Linked List
TEST_F(CommandProcessorTest, ListPushCommand) {
    CommandProcessor::execute("FPUSH 40 test_list.txt", "test_list.txt");
    
    // Проверяем что файл изменился
    auto values = readArrayFromFile("test_list.txt");
    EXPECT_NE(std::find(values.begin(), values.end(), 40), values.end());
}

TEST_F(CommandProcessorTest, ListDeleteCommand) {
    CommandProcessor::execute("FDEL 10 test_list.txt", "test_list.txt");
    
    auto values = readArrayFromFile("test_list.txt");
    EXPECT_EQ(std::find(values.begin(), values.end(), 10), values.end());
}

// Тесты для Stack
TEST_F(CommandProcessorTest, StackPushCommand) {
    CommandProcessor::execute("SPUSH 400 test_stack.txt", "test_stack.txt");
    
    auto values = readArrayFromFile("test_stack.txt");
    EXPECT_NE(std::find(values.begin(), values.end(), 400), values.end());
}

TEST_F(CommandProcessorTest, StackPopCommand) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("SPOP test_stack.txt", "test_stack.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    // Должен удалить верхний элемент (300)
    EXPECT_TRUE(output.find("300") != std::string::npos);
}

// Тесты для Queue
TEST_F(CommandProcessorTest, QueuePushCommand) {
    CommandProcessor::execute("QPUSH 80 test_queue.txt", "test_queue.txt");
    
    auto values = readArrayFromFile("test_queue.txt");
    EXPECT_NE(std::find(values.begin(), values.end(), 80), values.end());
}

TEST_F(CommandProcessorTest, QueuePopCommand) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("QPOP test_queue.txt", "test_queue.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    // Должен удалить первый элемент (50)
    EXPECT_TRUE(output.find("50") != std::string::npos);
}

// Тесты для Hash Table
TEST_F(CommandProcessorTest, HashAddCommand) {
    CommandProcessor::execute("HASHADD 4 400 test_hash.txt", "test_hash.txt");
    
    // Проверяем что файл изменился
    std::ifstream in("test_hash.txt");
    std::string line;
    bool found = false;
    while (std::getline(in, line)) {
        if (line.find("4 400") != std::string::npos) {
            found = true;
            break;
        }
    }
    in.close();
    
    EXPECT_TRUE(found);
}

TEST_F(CommandProcessorTest, HashDeleteCommand) {
    CommandProcessor::execute("HASHDEL 1 test_hash.txt", "test_hash.txt");
    
    // Проверяем что файл изменился
    std::ifstream in("test_hash.txt");
    std::string line;
    bool found = false;
    while (std::getline(in, line)) {
        if (line.find("1 100") != std::string::npos) {
            found = true;
            break;
        }
    }
    in.close();
    
    EXPECT_FALSE(found); // Элемент должен быть удален
}

TEST_F(CommandProcessorTest, HashGetCommand) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("HASHGET 2 test_hash.txt", "test_hash.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    EXPECT_TRUE(output.find("200") != std::string::npos);
}

// Тесты сериализации для Complete Binary Tree
TEST_F(CommandProcessorTest, TreeBinarySerialization) {
    // Сохраняем в бинарный формат
    CommandProcessor::execute("TREE_SAVE_BIN test_tree.txt", "test_tree.txt");
    
    // Проверяем что файл создан
    EXPECT_TRUE(fileExists("test_tree.txt.bin"));
    
    // Загружаем из бинарного формата
    CommandProcessor::execute("TREE_LOAD_BIN test_tree.bin", "test_tree.bin");
    
    // Проверяем что файл создан
    EXPECT_TRUE(fileExists("test_tree.bin"));
}

TEST_F(CommandProcessorTest, TreeTextSerialization) {
    // Сохраняем в текстовый формат
    CommandProcessor::execute("TREE_SAVE_TXT test_tree.txt", "test_tree.txt");
    
    // Проверяем что файл создан
    EXPECT_TRUE(fileExists("test_tree.txt.txt"));
    
    // Загружаем из текстового формата
    CommandProcessor::execute("TREE_LOAD_TXT test_tree_load.txt", "test_tree.txt");
    
    // Проверяем что файл существует и не пустой
    EXPECT_TRUE(fileExists("test_tree_load.txt"));
}

// Тест неизвестной команды
TEST_F(CommandProcessorTest, UnknownCommand) {
    testing::internal::CaptureStderr();
    CommandProcessor::execute("UNKNOWN_COMMAND test.txt", "test.txt");
    std::string output = testing::internal::GetCapturedStderr();
    
    EXPECT_TRUE(output.find("Неизвестная команда") != std::string::npos);
}

// Тест граничных случаев
TEST_F(CommandProcessorTest, EmptyFileOperations) {
    // Создаем пустой файл
    std::string empty_file = "empty.txt";
    registerFileForCleanup(empty_file);
    std::ofstream file(empty_file);
    file.close();
    
    testing::internal::CaptureStdout();
    CommandProcessor::execute("CBTPRINT empty.txt", "empty.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    // Должен вывести пустое дерево или Level Order без элементов
    EXPECT_FALSE(output.empty());
}

// Тест множественных операций
TEST_F(CommandProcessorTest, MultipleOperations) {
    CommandProcessor::execute("CBTINSERT 100 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTINSERT 200 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTINSERT 300 test_tree.txt", "test_tree.txt");
    
    EXPECT_TRUE(treeContainsValue("test_tree.txt", 100));
    EXPECT_TRUE(treeContainsValue("test_tree.txt", 200));
    EXPECT_TRUE(treeContainsValue("test_tree.txt", 300));
}

// Тест режимов хеширования
TEST_F(CommandProcessorTest, HashModeCommands) {
    testing::internal::CaptureStdout();
CommandProcessor::execute("SETOPENADDRESSING test_hash.txt", "test_hash.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    EXPECT_TRUE(output.find("Открытая адресаация") != std::string::npos);
    
    testing::internal::CaptureStdout();
    CommandProcessor::execute("SETCUCKOOHASH test_hash.txt", "test_hash.txt");
    output = testing::internal::GetCapturedStdout();
    
    EXPECT_TRUE(output.find("Метод цепочек") != std::string::npos);
    
    testing::internal::CaptureStdout();
CommandProcessor::execute("SETSEPARATECHAINING test_hash.txt", "test_hash.txt");
    output = testing::internal::GetCapturedStdout();
    
    EXPECT_TRUE(output.find("Метод свёртки") != std::string::npos);
}

// Тест вывода хеш-таблицы
TEST_F(CommandProcessorTest, HashPrintCommand) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("PRINTHASH test_hash.txt", "test_hash.txt");
    std::string output = testing::internal::GetCapturedStdout();
    
    EXPECT_FALSE(output.empty());
    EXPECT_TRUE(output.find("Hash Table") != std::string::npos);
}

// Расширенные тесты для Array
TEST_F(CommandProcessorTest, ArrayIndexCommands) {
    // Тестируем MINDEX и MSET
    CommandProcessor::execute("MINDEX 0 100 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MSET 0 999 test_array.txt", "test_array.txt");
    
    auto values = readArrayFromFile("test_array.txt");
    EXPECT_GE(values.size(), 1);
}

TEST_F(CommandProcessorTest, ListAdvancedCommands) {
    // Тестируем расширенные команды списков
    CommandProcessor::execute("FPUSHFRONT 99 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FINSERTBEFORE 20 88 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FINSERTAFTER 20 77 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FDELFRONT test_list.txt", "test_list.txt");
    CommandProcessor::execute("FDELBACK test_list.txt", "test_list.txt");
    CommandProcessor::execute("FCONTAINS 30 test_list.txt", "test_list.txt");
    
    // Для двусвязного списка
    CommandProcessor::execute("LPUSHFRONT 66 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LINSERTBEFORE 20 55 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LINSERTAFTER 20 44 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LCONTAINS 30 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LDELFRONT test_list.txt", "test_list.txt");
    CommandProcessor::execute("LDELBACK test_list.txt", "test_list.txt");
}

TEST_F(CommandProcessorTest, SerializationCommands) {
    // Тестируем команды сериализации
    CommandProcessor::execute("ARRAY_SAVE_BIN test_array.txt", "test_array.txt");
    CommandProcessor::execute("ARRAY_LOAD_BIN test_array.bin", "test_array.bin");
    CommandProcessor::execute("SLIST_SAVE_BIN test_list.txt", "test_list.txt");
    CommandProcessor::execute("SLIST_LOAD_BIN test_list.bin", "test_list.bin");
    CommandProcessor::execute("DLIST_SAVE_BIN test_list.txt", "test_list.txt");
    CommandProcessor::execute("DLIST_LOAD_BIN test_list.bin", "test_list.bin");
    CommandProcessor::execute("STACK_SAVE_BIN test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("STACK_LOAD_BIN test_stack.bin", "test_stack.bin");
    CommandProcessor::execute("QUEUE_SAVE_BIN test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("QUEUE_LOAD_BIN test_queue.bin", "test_queue.bin");
    CommandProcessor::execute("TREE_SAVE_BIN test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("TREE_LOAD_BIN test_tree.bin", "test_tree.bin");
    CommandProcessor::execute("HASH_SAVE_BIN test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASH_LOAD_BIN test_hash.bin", "test_hash.bin");
}

TEST_F(CommandProcessorTest, TextSerializationCommands) {
    // Тестируем текстовую сериализацию
    CommandProcessor::execute("ARRAY_SAVE_TXT test_array.txt", "test_array.txt");
    CommandProcessor::execute("ARRAY_LOAD_TXT test_array.txt.txt", "test_array.txt");
    CommandProcessor::execute("SLIST_SAVE_TXT test_list.txt", "test_list.txt");
    CommandProcessor::execute("SLIST_LOAD_TXT test_list.txt.txt", "test_list.txt");
    CommandProcessor::execute("TREE_SAVE_TXT test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("TREE_LOAD_TXT test_tree.txt.txt", "test_tree.txt");
}

TEST_F(CommandProcessorTest, ErrorHandlingCommands) {
    // Тестируем обработку ошибок
    testing::internal::CaptureStderr();
    CommandProcessor::execute("INVALID_COMMAND test.txt", "test.txt");
    std::string output = testing::internal::GetCapturedStderr();
    EXPECT_TRUE(output.find("Неизвестная команда") != std::string::npos);
    
    // Неправильные форматы команд
    CommandProcessor::execute("MPUSH invalid test_array.txt", "test_array.txt");
    CommandProcessor::execute("CBTINSERT invalid test_tree.txt", "test_tree.txt");
}

TEST_F(CommandProcessorTest, EdgeCaseCommands) {
    // Граничные случаи
    std::string empty_file = "empty.txt";
    registerFileForCleanup(empty_file);
    std::ofstream file(empty_file);
    file.close();
    
    CommandProcessor::execute("PRINTM empty.txt", "empty.txt");
    CommandProcessor::execute("PRINTF empty.txt", "empty.txt");
    CommandProcessor::execute("PRINTL empty.txt", "empty.txt");
    CommandProcessor::execute("PRINTS empty.txt", "empty.txt");
    CommandProcessor::execute("PRINTQ empty.txt", "empty.txt");
    CommandProcessor::execute("CBTPRINT empty.txt", "empty.txt");
}

// Расширенные тесты для Array
TEST_F(CommandProcessorTest, ArrayComplexOperations) {
    CommandProcessor::execute("MINDEX 2 50 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MSET 1 25 test_array.txt", "test_array.txt");
    
    auto values = readArrayFromFile("test_array.txt");
    EXPECT_GE(values.size(), 5);
}

TEST_F(CommandProcessorTest, ArrayMultipleOperations) {
    CommandProcessor::execute("MPUSH 100 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MPUSH 200 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MDEL 0 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MGET 1 test_array.txt", "test_array.txt");
    
    auto values = readArrayFromFile("test_array.txt");
    EXPECT_FALSE(values.empty());
}

// Расширенные тесты для SinglyLinkedList
TEST_F(CommandProcessorTest, SinglyListComplexOperations) {
    CommandProcessor::execute("FPUSHFRONT 5 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FINSERTBEFORE 20 15 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FINSERTAFTER 20 25 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FDELFRONT test_list.txt", "test_list.txt");
    CommandProcessor::execute("FDELBACK test_list.txt", "test_list.txt");
    CommandProcessor::execute("FCONTAINS 15 test_list.txt", "test_list.txt");
    
    auto values = readArrayFromFile("test_list.txt");
    EXPECT_FALSE(values.empty());
}

// Расширенные тесты для DoublyLinkedList
TEST_F(CommandProcessorTest, DoublyListComplexOperations) {
    CommandProcessor::execute("LPUSHFRONT 5 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LINSERTBEFORE 20 15 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LINSERTAFTER 20 25 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LCONTAINS 15 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LDELFRONT test_list.txt", "test_list.txt");
    CommandProcessor::execute("LDELBACK test_list.txt", "test_list.txt");
    
    auto values = readArrayFromFile("test_list.txt");
    EXPECT_FALSE(values.empty());
}

// Расширенные тесты для Stack
TEST_F(CommandProcessorTest, StackComplexOperations) {
    CommandProcessor::execute("SPUSH 500 test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("SPUSH 600 test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("SPOP test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("SPOP test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("PRINTS test_stack.txt", "test_stack.txt");
    
    auto values = readArrayFromFile("test_stack.txt");
    EXPECT_FALSE(values.empty());
}

// Расширенные тесты для Queue
TEST_F(CommandProcessorTest, QueueComplexOperations) {
    CommandProcessor::execute("QPUSH 90 test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("QPUSH 100 test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("QPOP test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("QPOP test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("PRINTQ test_queue.txt", "test_queue.txt");
    
    auto values = readArrayFromFile("test_queue.txt");
    EXPECT_FALSE(values.empty());
}

// Расширенные тесты для CompleteBinaryTree
TEST_F(CommandProcessorTest, TreeComplexOperations) {
    CommandProcessor::execute("CBTINSERT 50 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTINSERT 60 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTDEL 5 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTGET 7 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTVALIDATE test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTPRINT test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTPRINT_TREE test_tree.txt", "test_tree.txt");
    
    EXPECT_TRUE(treeContainsValue("test_tree.txt", 50));
}

// Расширенные тесты для HashTable
TEST_F(CommandProcessorTest, HashTableComplexOperations) {
    CommandProcessor::execute("SETDOUBLEHASH test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHADD 10 1000 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHADD 20 2000 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHDEL 1 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHGET 2 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("PRINTHASH test_hash.txt", "test_hash.txt");
    
    CommandProcessor::execute("SETCUCKOOHASH test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("SETFOLDHASH test_hash.txt", "test_hash.txt");
}

// Тесты всех команд сериализации
TEST_F(CommandProcessorTest, AllBinarySerializationCommands) {
    CommandProcessor::execute("ARRAY_SAVE_BIN test_array.txt", "test_array.txt");
    CommandProcessor::execute("SLIST_SAVE_BIN test_list.txt", "test_list.txt");
    CommandProcessor::execute("DLIST_SAVE_BIN test_list.txt", "test_list.txt");
    CommandProcessor::execute("STACK_SAVE_BIN test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("QUEUE_SAVE_BIN test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("TREE_SAVE_BIN test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("HASH_SAVE_BIN test_hash.txt", "test_hash.txt");
    
    EXPECT_TRUE(fileExists("test_array.txt.bin"));
    EXPECT_TRUE(fileExists("test_list.txt.bin"));
    EXPECT_TRUE(fileExists("test_stack.txt.bin"));
    EXPECT_TRUE(fileExists("test_queue.txt.bin"));
    EXPECT_TRUE(fileExists("test_tree.txt.bin"));
    EXPECT_TRUE(fileExists("test_hash.txt.bin"));
}

TEST_F(CommandProcessorTest, AllTextSerializationCommands) {
    CommandProcessor::execute("ARRAY_SAVE_TXT test_array.txt", "test_array.txt");
    CommandProcessor::execute("SLIST_SAVE_TXT test_list.txt", "test_list.txt");
    CommandProcessor::execute("DLIST_SAVE_TXT test_list.txt", "test_list.txt");
    CommandProcessor::execute("STACK_SAVE_TXT test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("QUEUE_SAVE_TXT test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("TREE_SAVE_TXT test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("HASH_SAVE_TXT test_hash.txt", "test_hash.txt");
    
    EXPECT_TRUE(fileExists("test_array.txt.txt"));
    EXPECT_TRUE(fileExists("test_list.txt.txt"));
    EXPECT_TRUE(fileExists("test_stack.txt.txt"));
    EXPECT_TRUE(fileExists("test_queue.txt.txt"));
    EXPECT_TRUE(fileExists("test_tree.txt.txt"));
    EXPECT_TRUE(fileExists("test_hash.txt.txt"));
}

// Тесты загрузки сериализованных данных
TEST_F(CommandProcessorTest, LoadSerializedData) {
    // Сначала сохраняем
    CommandProcessor::execute("ARRAY_SAVE_BIN test_array.txt", "test_array.txt");
    CommandProcessor::execute("TREE_SAVE_BIN test_tree.txt", "test_tree.txt");
    
    // Потом загружаем
    CommandProcessor::execute("ARRAY_LOAD_BIN test_array.txt.bin", "test_array_loaded.txt");
    CommandProcessor::execute("TREE_LOAD_BIN test_tree.txt.bin", "test_tree_loaded.txt");
    
    EXPECT_TRUE(fileExists("test_array_loaded.txt"));
    EXPECT_TRUE(fileExists("test_tree_loaded.txt"));
}

// Тесты обработки ошибок и граничных случаев
TEST_F(CommandProcessorTest, InvalidInputHandling) {
    testing::internal::CaptureStderr();
    CommandProcessor::execute("MPUSH abc test_array.txt", "test_array.txt");
    std::string output = testing::internal::GetCapturedStderr();
    EXPECT_FALSE(output.empty());
    
    testing::internal::CaptureStderr();
    CommandProcessor::execute("CBTINSERT xyz test_tree.txt", "test_tree.txt");
    output = testing::internal::GetCapturedStderr();
    EXPECT_FALSE(output.empty());
    
    testing::internal::CaptureStderr();
    CommandProcessor::execute("MGET invalid test_array.txt", "test_array.txt");
    output = testing::internal::GetCapturedStderr();
    EXPECT_FALSE(output.empty());
}

TEST_F(CommandProcessorTest, FileNotFoundOperations) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("PRINTM nonexistent.txt", "nonexistent.txt");
    std::string output = testing::internal::GetCapturedStdout();
    EXPECT_FALSE(output.empty());
    
    testing::internal::CaptureStdout();
    CommandProcessor::execute("CBTPRINT nonexistent.txt", "nonexistent.txt");
    output = testing::internal::GetCapturedStdout();
    EXPECT_FALSE(output.empty());
}

// Тесты последовательных операций
TEST_F(CommandProcessorTest, SequentialOperations) {
    // Массив
    CommandProcessor::execute("MPUSH 1000 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MINDEX 1 999 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MSET 2 888 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MDEL 0 test_array.txt", "test_array.txt");
    CommandProcessor::execute("PRINTM test_array.txt", "test_array.txt");
    
    // Дерево
    CommandProcessor::execute("CBTINSERT 100 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTINSERT 200 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTDEL 100 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTPRINT test_tree.txt", "test_tree.txt");
    
    // Хеш-таблица
    CommandProcessor::execute("HASHADD 100 10000 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHADD 200 20000 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHDEL 100 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("PRINTHASH test_hash.txt", "test_hash.txt");
}

// Тесты производительности (быстрые операции)
TEST_F(CommandProcessorTest, PerformanceOperations) {
    for (int i = 0; i < 10; i++) {
        CommandProcessor::execute("MPUSH " + std::to_string(i * 10) + " test_array.txt", "test_array.txt");
    }
    
    for (int i = 0; i < 5; i++) {
        CommandProcessor::execute("CBTINSERT " + std::to_string(i * 20) + " test_tree.txt", "test_tree.txt");
    }
    
    auto array_values = readArrayFromFile("test_array.txt");
    EXPECT_GE(array_values.size(), 10);
}

// Тесты всех команд вывода
TEST_F(CommandProcessorTest, AllPrintCommands) {
    testing::internal::CaptureStdout();
    CommandProcessor::execute("PRINTM test_array.txt", "test_array.txt");
    std::string output = testing::internal::GetCapturedStdout();
    EXPECT_FALSE(output.empty());
    
    testing::internal::CaptureStdout();
    CommandProcessor::execute("PRINTF test_list.txt", "test_list.txt");
    output = testing::internal::GetCapturedStdout();
    EXPECT_FALSE(output.empty());
    
    testing::internal::CaptureStdout();
    CommandProcessor::execute("PRINTL test_list.txt", "test_list.txt");
    output = testing::internal::GetCapturedStdout();
    EXPECT_FALSE(output.empty());
    
    testing::internal::CaptureStdout();
    CommandProcessor::execute("PRINTS test_stack.txt", "test_stack.txt");
    output = testing::internal::GetCapturedStdout();
    EXPECT_FALSE(output.empty());
    
    testing::internal::CaptureStdout();
    CommandProcessor::execute("PRINTQ test_queue.txt", "test_queue.txt");
    output = testing::internal::GetCapturedStdout();
    EXPECT_FALSE(output.empty());
    
    testing::internal::CaptureStdout();
    CommandProcessor::execute("CBTPRINT test_tree.txt", "test_tree.txt");
    output = testing::internal::GetCapturedStdout();
    EXPECT_FALSE(output.empty());
    
    testing::internal::CaptureStdout();
    CommandProcessor::execute("PRINTHASH test_hash.txt", "test_hash.txt");
    output = testing::internal::GetCapturedStdout();
    EXPECT_FALSE(output.empty());
}

// Тесты для всех вариантов команд Array
TEST_F(CommandProcessorTest, ArrayAllCommandsComprehensive) {
    // Тестируем все возможные команды массива
    CommandProcessor::execute("MPUSH 111 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MINDEX 0 222 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MINDEX 5 333 test_array.txt", "test_array.txt"); // за пределами
    CommandProcessor::execute("MSET 1 444 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MDEL 0 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MDEL 10 test_array.txt", "test_array.txt"); // несуществующий индекс
    CommandProcessor::execute("MGET 0 test_array.txt", "test_array.txt");
    CommandProcessor::execute("MGET 10 test_array.txt", "test_array.txt"); // несуществующий индекс
    CommandProcessor::execute("PRINTM test_array.txt", "test_array.txt");
    
    auto values = readArrayFromFile("test_array.txt");
    EXPECT_FALSE(values.empty());
}

// Тесты для всех вариантов команд SinglyLinkedList
TEST_F(CommandProcessorTest, SinglyListAllCommandsComprehensive) {
    CommandProcessor::execute("FPUSH 111 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FPUSHFRONT 222 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FINSERTBEFORE 20 333 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FINSERTAFTER 20 444 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FINSERTBEFORE 999 555 test_list.txt", "test_list.txt"); // несуществующий
    CommandProcessor::execute("FINSERTAFTER 999 666 test_list.txt", "test_list.txt"); // несуществующий
    CommandProcessor::execute("FDEL 10 test_list.txt", "test_list.txt"); // несуществующий
    CommandProcessor::execute("FDEL 20 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FDELFRONT test_list.txt", "test_list.txt");
    CommandProcessor::execute("FDELBACK test_list.txt", "test_list.txt");
    CommandProcessor::execute("FGET 0 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FGET 10 test_list.txt", "test_list.txt"); // несуществующий
    CommandProcessor::execute("FCONTAINS 30 test_list.txt", "test_list.txt");
    CommandProcessor::execute("FCONTAINS 999 test_list.txt", "test_list.txt"); // несуществующий
    CommandProcessor::execute("PRINTF test_list.txt", "test_list.txt");
}

// Тесты для всех вариантов команд DoublyLinkedList
TEST_F(CommandProcessorTest, DoublyListAllCommandsComprehensive) {
    CommandProcessor::execute("LPUSH 111 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LPUSHFRONT 222 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LINSERTBEFORE 20 333 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LINSERTAFTER 20 444 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LINSERTBEFORE 999 555 test_list.txt", "test_list.txt"); // несуществующий
    CommandProcessor::execute("LINSERTAFTER 999 666 test_list.txt", "test_list.txt"); // несуществующий
    CommandProcessor::execute("LDEL 10 test_list.txt", "test_list.txt"); // несуществующий
    CommandProcessor::execute("LDEL 20 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LDELFRONT test_list.txt", "test_list.txt");
    CommandProcessor::execute("LDELBACK test_list.txt", "test_list.txt");
    CommandProcessor::execute("LGET 0 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LGET 10 test_list.txt", "test_list.txt"); // несуществующий
    CommandProcessor::execute("LCONTAINS 30 test_list.txt", "test_list.txt");
    CommandProcessor::execute("LCONTAINS 999 test_list.txt", "test_list.txt"); // несуществующий
    CommandProcessor::execute("PRINTL test_list.txt", "test_list.txt");
}

// Тесты для всех вариантов команд Stack
TEST_F(CommandProcessorTest, StackAllCommandsComprehensive) {
    CommandProcessor::execute("SPUSH 111 test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("SPUSH 222 test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("SPUSH 333 test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("SPOP test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("SPOP test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("SPOP test_stack.txt", "test_stack.txt");
    CommandProcessor::execute("SPOP test_stack.txt", "test_stack.txt"); // пустой стек
    CommandProcessor::execute("PRINTS test_stack.txt", "test_stack.txt");
}

// Тесты для всех вариантов команд Queue
TEST_F(CommandProcessorTest, QueueAllCommandsComprehensive) {
    CommandProcessor::execute("QPUSH 111 test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("QPUSH 222 test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("QPUSH 333 test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("QPOP test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("QPOP test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("QPOP test_queue.txt", "test_queue.txt");
    CommandProcessor::execute("QPOP test_queue.txt", "test_queue.txt"); // пустая очередь
    CommandProcessor::execute("PRINTQ test_queue.txt", "test_queue.txt");
}

// Тесты для всех вариантов команд CompleteBinaryTree
TEST_F(CommandProcessorTest, TreeAllCommandsComprehensive) {
    CommandProcessor::execute("CBTINSERT 111 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTINSERT 222 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTINSERT 333 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTDEL 111 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTDEL 999 test_tree.txt", "test_tree.txt"); // несуществующий
    CommandProcessor::execute("CBTGET 222 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTGET 999 test_tree.txt", "test_tree.txt"); // несуществующий
    CommandProcessor::execute("CBTVALIDATE test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTPRINT test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("CBTPRINT_TREE test_tree.txt", "test_tree.txt");
}

// Тесты для всех вариантов команд HashTable
TEST_F(CommandProcessorTest, HashTableAllCommandsComprehensive) {
    CommandProcessor::execute("SETDOUBLEHASH test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHADD 111 1111 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHADD 222 2222 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHADD 333 3333 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHDEL 111 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHDEL 999 test_hash.txt", "test_hash.txt"); // несуществующий
    CommandProcessor::execute("HASHGET 222 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHGET 999 test_hash.txt", "test_hash.txt"); // несуществующий
    CommandProcessor::execute("PRINTHASH test_hash.txt", "test_hash.txt");
    
    CommandProcessor::execute("SETCUCKOOHASH test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("SETFOLDHASH test_hash.txt", "test_hash.txt");
}

// Тесты всех команд сериализации с разными файлами
TEST_F(CommandProcessorTest, AllSerializationWithDifferentFiles) {
    // Бинарная сериализация для всех структур
    CommandProcessor::execute("ARRAY_SAVE_BIN test_array.txt", "array_bin.bin");
    CommandProcessor::execute("SLIST_SAVE_BIN test_list.txt", "slist_bin.bin");
    CommandProcessor::execute("DLIST_SAVE_BIN test_list.txt", "dlist_bin.bin");
    CommandProcessor::execute("STACK_SAVE_BIN test_stack.txt", "stack_bin.bin");
    CommandProcessor::execute("QUEUE_SAVE_BIN test_queue.txt", "queue_bin.bin");
    CommandProcessor::execute("TREE_SAVE_BIN test_tree.txt", "tree_bin.bin");
    CommandProcessor::execute("HASH_SAVE_BIN test_hash.txt", "hash_bin.bin");
    
    // Текстовая сериализация для всех структур
    CommandProcessor::execute("ARRAY_SAVE_TXT test_array.txt", "array_txt.txt");
    CommandProcessor::execute("SLIST_SAVE_TXT test_list.txt", "slist_txt.txt");
    CommandProcessor::execute("DLIST_SAVE_TXT test_list.txt", "dlist_txt.txt");
    CommandProcessor::execute("STACK_SAVE_TXT test_stack.txt", "stack_txt.txt");
    CommandProcessor::execute("QUEUE_SAVE_TXT test_queue.txt", "queue_txt.txt");
    CommandProcessor::execute("TREE_SAVE_TXT test_tree.txt", "tree_txt.txt");
    CommandProcessor::execute("HASH_SAVE_TXT test_hash.txt", "hash_txt.txt");
    
    // Загрузка всех бинарных файлов
    CommandProcessor::execute("ARRAY_LOAD_BIN array_bin.bin", "array_loaded.txt");
    CommandProcessor::execute("SLIST_LOAD_BIN slist_bin.bin", "slist_loaded.txt");
    CommandProcessor::execute("DLIST_LOAD_BIN dlist_bin.bin", "dlist_loaded.txt");
    CommandProcessor::execute("STACK_LOAD_BIN stack_bin.bin", "stack_loaded.txt");
    CommandProcessor::execute("QUEUE_LOAD_BIN queue_bin.bin", "queue_loaded.txt");
    CommandProcessor::execute("TREE_LOAD_BIN tree_bin.bin", "tree_loaded.txt");
    CommandProcessor::execute("HASH_LOAD_BIN hash_bin.bin", "hash_loaded.txt");
    
    // Загрузка всех текстовых файлов
    CommandProcessor::execute("ARRAY_LOAD_TXT array_txt.txt", "array_txt_loaded.txt");
    CommandProcessor::execute("SLIST_LOAD_TXT slist_txt.txt", "slist_txt_loaded.txt");
    CommandProcessor::execute("DLIST_LOAD_TXT dlist_txt.txt", "dlist_txt_loaded.txt");
    CommandProcessor::execute("STACK_LOAD_TXT stack_txt.txt", "stack_txt_loaded.txt");
    CommandProcessor::execute("QUEUE_LOAD_TXT queue_txt.txt", "queue_txt_loaded.txt");
    CommandProcessor::execute("TREE_LOAD_TXT tree_txt.txt", "tree_txt_loaded.txt");
    CommandProcessor::execute("HASH_LOAD_TXT hash_txt.txt", "hash_txt_loaded.txt");
}

// Тесты комбинаций команд
TEST_F(CommandProcessorTest, CommandCombinations) {
    // Комбинации Array + Serialization
    CommandProcessor::execute("MPUSH 100 test_array.txt", "test_array.txt");
    CommandProcessor::execute("ARRAY_SAVE_BIN test_array.txt", "test_array.txt");
    CommandProcessor::execute("ARRAY_LOAD_BIN test_array.txt.bin", "test_array_new.txt");
    CommandProcessor::execute("PRINTM test_array_new.txt", "test_array_new.txt");
    
    // Комбинации Tree + Serialization
    CommandProcessor::execute("CBTINSERT 500 test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("TREE_SAVE_BIN test_tree.txt", "test_tree.txt");
    CommandProcessor::execute("TREE_LOAD_BIN test_tree.txt.bin", "test_tree_new.txt");
    CommandProcessor::execute("CBTPRINT test_tree_new.txt", "test_tree_new.txt");
    
    // Комбинации Hash + Mode changes
    CommandProcessor::execute("SETDOUBLEHASH test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHADD 500 5000 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("SETCUCKOOHASH test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHADD 600 6000 test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("SETFOLDHASH test_hash.txt", "test_hash.txt");
    CommandProcessor::execute("HASHADD 700 7000 test_hash.txt", "test_hash.txt");
}