#pragma once
#include <algorithm>
#include <iostream>
#include <optional>
#include <utility>
#include <vector>
#include <list>

enum class HashType { OPEN_ADDRESSING, SEPARATE_CHAINING, FOLDING_HASHING };

class HashTable {
private:
  // Для OPEN_ADDRESSING и FOLDING_HASHING
  std::vector<std::optional<std::pair<int, int>>> table;
  // Для SEPARATE_CHAINING
  std::vector<std::list<std::pair<int, int>>> chainTable;
  
  int size;
  HashType type;

  int hashFunc1(int key) const { return key % size; }
  int hashFunc2(int key) const { return 1 + (key % std::max(size - 1, 1)); }

  int foldingHash(int key, bool verbose = false) const;

  double loadFactor() const;
  void rehash();
  void rehashChaining();
  void insertOpenAddressing(int key, int value);

public:
  explicit HashTable(int s = 11, HashType t = HashType::OPEN_ADDRESSING);

  void insert(int key, int value);
  bool remove(int key);
  std::vector<std::pair<int, int>> toVector() const;
  HashType getType() const { return type; }
  int getSize() const { return size; }
  std::optional<int> get(int key) const;
  void print() const;
  void clear();

  void serializeBinary(std::ostream &os) const;
  void deserializeBinary(std::istream &is);
  void serializeText(std::ostream &os) const;
  void deserializeText(std::istream &is);
};