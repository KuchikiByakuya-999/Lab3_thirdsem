#include "../include/DoublyLinkedList.h"

DoublyLinkedList::DoublyLinkedList() : head(nullptr), tail(nullptr) {}

DoublyLinkedList::~DoublyLinkedList() {
  while (head != nullptr) {
    LNode *tmp = head;
    head = head->next;
    delete tmp;
  }
}

void DoublyLinkedList::pushFront(int value) {
  LNode *node = new LNode(value);
  node->next = head;
  if (head != nullptr) {
    head->prev = node;
  }
  head = node;
  if (tail == nullptr) {
    tail = node;
  }
}

void DoublyLinkedList::pushBack(int value) {
  LNode *node = new LNode(value);
  node->prev = tail;
  if (tail != nullptr) {
    tail->next = node;
  }
  tail = node;
  if (head == nullptr) {
    head = node;
  }
}

bool DoublyLinkedList::delByValue(int value) {
  LNode *curr = head;
  while (curr != nullptr && curr->data != value) {
    curr = curr->next;
  }
  if (curr == nullptr) {
    return false;
  }

  if (curr->prev != nullptr) {
    curr->prev->next = curr->next;
  } else {
    head = curr->next;
  }

  if (curr->next != nullptr) {
    curr->next->prev = curr->prev;
  } else {
    tail = curr->prev;
  }

  delete curr;
  return true;
}

int DoublyLinkedList::get(int index) const {
  LNode *curr = head;
  int i = 0;
  while (curr != nullptr) {
    if (i == index) {
      return curr->data;
    }
    curr = curr->next;
    i++;
  }
  std::cerr << "Ошибка: индекс вне диапазона\n";
  return -1;
}

void DoublyLinkedList::print() const {
  LNode *curr = head;
  while (curr != nullptr) {
    std::cout << curr->data << " ";
    curr = curr->next;
  }
  std::cout << std::endl;
}

void DoublyLinkedList::insertBefore(int target, int value) {
  LNode *curr = head;
  while (curr != nullptr && curr->data != target) {
    curr = curr->next;
  }
  if (curr == nullptr) {
    return;
  }

  LNode *node = new LNode(value);
  node->next = curr;
  node->prev = curr->prev;

  if (curr->prev != nullptr) {
    curr->prev->next = node;
  } else {
    head = node;
  }
  curr->prev = node;
}

void DoublyLinkedList::insertAfter(int target, int value) {
  LNode *curr = head;
  while (curr != nullptr && curr->data != target) {
    curr = curr->next;
  }
  if (curr == nullptr) {
    return;
  }

  LNode *node = new LNode(value);
  node->prev = curr;
  node->next = curr->next;

  if (curr->next != nullptr) {
    curr->next->prev = node;
  } else {
    tail = node;
  }
  curr->next = node;
}

std::vector<int> DoublyLinkedList::toVector() const {
  std::vector<int> result;
  LNode *curr = head;
  while (curr != nullptr) {
    result.push_back(curr->data);
    curr = curr->next;
  }
  return result;
}

bool DoublyLinkedList::contains(int value) const {
  LNode *curr = head;
  while (curr != nullptr) {
    if (curr->data == value) {
      return true;
    }
    curr = curr->next;
  }
  return false;
}

bool DoublyLinkedList::delFront() {
  if (head == nullptr) {
    std::cerr << "Ошибка: список пуст\n";
    return false;
  }
  LNode *tmp = head;
  head = head->next;
  if (head != nullptr) {
    head->prev = nullptr;
  } else {
    tail = nullptr;
  }
  delete tmp;
  return true;
}

bool DoublyLinkedList::delBack() {
  if (tail == nullptr) {
    std::cerr << "Ошибка: список пуст\n";
    return false;
  }
  LNode *tmp = tail;
  tail = tail->prev;
  if (tail != nullptr) {
    tail->next = nullptr;
  } else {
    head = nullptr;
  }
  delete tmp;
  return true;
}

void DoublyLinkedList::serializeBinary(std::ostream &os) const {
  std::vector<int> vec = toVector();
  size_t vec_size = vec.size();
  os.write(reinterpret_cast<const char *>(&vec_size), sizeof(vec_size));
  if (vec_size > 0) {
    os.write(reinterpret_cast<const char *>(vec.data()),
             vec_size * sizeof(int));
  }
}

void DoublyLinkedList::deserializeBinary(std::istream &is) {
  while (head != nullptr) {
    LNode *tmp = head;
    head = head->next;
    delete tmp;
  }
  tail = nullptr;

  size_t vec_size;
  is.read(reinterpret_cast<char *>(&vec_size), sizeof(vec_size));

  if (vec_size > 0) {
    std::vector<int> temp(vec_size);
    is.read(reinterpret_cast<char *>(temp.data()), vec_size * sizeof(int));

    for (int value : temp) {
      pushBack(value);
    }
  }
}

void DoublyLinkedList::serializeText(std::ostream &os) const {
  std::vector<int> vec = toVector();
  for (size_t i = 0; i < vec.size(); ++i) {
    os << vec[i];
    if (i < vec.size() - 1) {
      os << " ";
    }
  }
}

void DoublyLinkedList::deserializeText(std::istream &is) {
  while (head != nullptr) {
    LNode *tmp = head;
    head = head->next;
    delete tmp;
  }
  tail = nullptr;

  int value;
  while (is >> value) {
    pushBack(value);
  }
}