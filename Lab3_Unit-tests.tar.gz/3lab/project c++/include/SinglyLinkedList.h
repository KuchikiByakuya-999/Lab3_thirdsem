#pragma once
#include <iostream>
#include <vector>

struct FNode {
  int data;
  FNode *next;
  explicit FNode(int val) : data(val), next(nullptr) {}
};

class SinglyLinkedList {
private:
  FNode *head;

public:
  SinglyLinkedList();
  ~SinglyLinkedList();

  bool contains(int value) const;

  void pushFront(int value);
  void pushBack(int value);
  void insertBefore(int target, int value);
  void insertAfter(int target, int value) const; // Убрано const
  bool delByValue(int value);
  bool delFront();
  bool delBack();
  int get(int index) const;
  void print() const;
  std::vector<int> toVector() const;

  void serializeBinary(std::ostream &os) const;
  void deserializeBinary(std::istream &is);
  void serializeText(std::ostream &os) const;
  void deserializeText(std::istream &is);
};