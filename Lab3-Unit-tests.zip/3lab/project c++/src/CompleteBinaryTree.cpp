#include "../include/CompleteBinaryTree.h"
#include <algorithm> 
#include <cmath>
#include <functional>
#include <queue> 

CompleteBinaryTree::CompleteBinaryTree() : root(nullptr), nodeCount(0) {}

CompleteBinaryTree::CompleteBinaryTree(const CompleteBinaryTree &other)
    : root(nullptr), nodeCount(0) {
  if (other.root != nullptr) {
    root = copyTree(other.root, nullptr);
    nodeCount = other.nodeCount;
  }
}

CompleteBinaryTree &
CompleteBinaryTree::operator=(const CompleteBinaryTree &other) {
  if (this != &other) {
    // Очищаем текущее дерево
    deleteTree(root);
    root = nullptr;
    nodeCount = 0;

    // Копируем из other
    if (other.root != nullptr) {
      root = copyTree(other.root, nullptr);
      nodeCount = other.nodeCount;
    }
  }
  return *this;
}

CompleteBinaryTree::~CompleteBinaryTree() { deleteTree(root); }

// Вспомогательная функция для копирования дерева
CBTNode *CompleteBinaryTree::copyTree(CBTNode *node, CBTNode *parent) {
  if (node == nullptr) {
    return nullptr;
  }

  CBTNode *newNode = new CBTNode(node->data);
  newNode->parent = parent;
  newNode->left = copyTree(node->left, newNode);
  newNode->right = copyTree(node->right, newNode);

  return newNode;
}

void CompleteBinaryTree::deleteTree(CBTNode *node) {
  if (node == nullptr) {
    return;
  }
  deleteTree(node->left);
  deleteTree(node->right);
  delete node;
}

// Вставка в Complete Binary Tree
void CompleteBinaryTree::insert(int value) {
  CBTNode *newNode = new CBTNode(value);

  if (root == nullptr) {
    root = newNode;
    nodeCount++;
    return;
  }

  // Находим родителя для новой ноды
  CBTNode *parent = getParentOfNextInsertion();

  if (parent->left == nullptr) {
    parent->left = newNode;
  } else {
    parent->right = newNode;
  }

  newNode->parent = parent;
  nodeCount++;
}

// Получение родителя для следующей вставки
CBTNode *CompleteBinaryTree::getParentOfNextInsertion() const {
  if (root == nullptr) {
    return nullptr;
  }

  std::queue<CBTNode *> q;
  q.push(root);

  while (!q.empty()) {
    CBTNode *current = q.front();
    q.pop();

    if (current->left == nullptr || current->right == nullptr) {
      return current;
    }

    q.push(current->left);
    q.push(current->right);
  }

  return nullptr; // Не должно происходить
}

// Получение последней ноды
CBTNode *CompleteBinaryTree::getLastNode() const {
  if (root == nullptr) {
    return nullptr;
  }

  std::queue<CBTNode *> q;
  q.push(root);
  CBTNode *last = nullptr;

  while (!q.empty()) {
    last = q.front();
    q.pop();

    if (last->left != nullptr) {
      q.push(last->left);
    }
    if (last->right != nullptr) {
      q.push(last->right);
    }
  }

  return last;
}

bool CompleteBinaryTree::remove(int value) {
    if (root == nullptr) {
        return false;
    }

    // Находим ноду для удаления
    CBTNode* nodeToDelete = findNode(value);
    if (nodeToDelete == nullptr) {
        return false;
    }

    // Находим последнюю ноду
    CBTNode* lastNode = getLastNode();
    if (lastNode == nullptr) {
        return false;
    }

    if (nodeToDelete == lastNode) {
        // Удаляем последнюю ноду
        if (lastNode == root) {
            root = nullptr;
        } else {
            if (lastNode->parent->left == lastNode) {
                lastNode->parent->left = nullptr;
            } else {
                lastNode->parent->right = nullptr;
            }
        }
        delete lastNode;
    } else {
        // Заменяем данные и удаляем последнюю ноду
        nodeToDelete->data = lastNode->data;

        if (lastNode->parent != nullptr) {
            if (lastNode->parent->left == lastNode) {
                lastNode->parent->left = nullptr;
            } else {
                lastNode->parent->right = nullptr;
            }
        }
        delete lastNode;
    }

    nodeCount--;
    return true;
}

// Поиск ноды
CBTNode *CompleteBinaryTree::findNode(int value) const {
  return findNodeHelper(root, value);
}

CBTNode *CompleteBinaryTree::findNodeHelper(CBTNode *node, int value) {
  if (node == nullptr) {
    return nullptr;
  }
  if (node->data == value) {
    return node;
  }

  CBTNode *leftResult = findNodeHelper(node->left, value);
  if (leftResult != nullptr) {
    return leftResult;
  }

  return findNodeHelper(node->right, value);
}

bool CompleteBinaryTree::contains(int value) const {
  return findNode(value) != nullptr;
}

// Обходы дерева
std::vector<int> CompleteBinaryTree::inorder() const {
  std::vector<int> result;
  inorderHelper(root, result);
  return result;
}

void CompleteBinaryTree::inorderHelper(CBTNode *node,
                                       std::vector<int> &result) {
  if (node == nullptr) {
    return;
  }
  inorderHelper(node->left, result);
  result.push_back(node->data);
  inorderHelper(node->right, result);
}

std::vector<int> CompleteBinaryTree::preorder() const {
  std::vector<int> result;
  preorderHelper(root, result);
  return result;
}

void CompleteBinaryTree::preorderHelper(CBTNode *node,
                                        std::vector<int> &result) {
  if (node == nullptr) {
    return;
  }
  result.push_back(node->data);
  preorderHelper(node->left, result);
  preorderHelper(node->right, result);
}

std::vector<int> CompleteBinaryTree::postorder() const {
  std::vector<int> result;
  postorderHelper(root, result);
  return result;
}

void CompleteBinaryTree::postorderHelper(CBTNode *node,
                                         std::vector<int> &result) {
  if (node == nullptr) {
    return;
  }
  postorderHelper(node->left, result);
  postorderHelper(node->right, result);
  result.push_back(node->data);
}

std::vector<int> CompleteBinaryTree::levelOrder() const {
  std::vector<int> result;
  levelOrderHelper(result);
  return result;
}

void CompleteBinaryTree::levelOrderHelper(std::vector<int> &result) const {
  if (root == nullptr) {
    return;
  }

  std::queue<CBTNode *> q;
  q.push(root);

  while (!q.empty()) {
    CBTNode *current = q.front();
    q.pop();
    result.push_back(current->data);

    if (current->left != nullptr) {
      q.push(current->left);
    }
    if (current->right != nullptr) {
      q.push(current->right);
    }
  }
}

// Высота дерева
int CompleteBinaryTree::height() const { return getHeight(root); }

int CompleteBinaryTree::getHeight(CBTNode *node) {
  if (node == nullptr) {
    return 0;
  }
  return 1 + std::max(getHeight(node->left), getHeight(node->right));
}

// Проверка complete свойства
bool CompleteBinaryTree::isComplete() const {
  if (root == nullptr) {
    return true;
  }

  std::queue<CBTNode *> q;
  q.push(root);
  bool foundNonFull = false;

  while (!q.empty()) {
    CBTNode *current = q.front();
    q.pop();

    if (current->left != nullptr) {
      if (foundNonFull) {
        return false;
      }
      q.push(current->left);
    } else {
      foundNonFull = true;
    }

    if (current->right != nullptr) {
      if (foundNonFull) {
        return false;
      }
      q.push(current->right);
    } else {
      foundNonFull = true;
    }
  }

  return true;
}

// Проверка perfect свойства
bool CompleteBinaryTree::isPerfect() const {
  if (root == nullptr) {
    return true;
  }

  int h = height();
  int expectedNodes = (1 << h) - 1; // 2^h - 1
  return nodeCount == expectedNodes;
}

// Валидация дерева
bool CompleteBinaryTree::validate() const {
  bool completeCheck = isComplete();

  // Простая проверка балансировки - для Complete Binary Tree высота должна быть
  // O(log n)
  bool heightCheck = true;
  if (nodeCount > 0) {
    int h = height();
    int maxExpectedHeight = 2 * static_cast<int>(std::log2(nodeCount + 1));
    heightCheck = h <= maxExpectedHeight;
  }

  std::cout << "Complete Binary Tree Validation:\n";
  std::cout << "  - Is Complete: " << (completeCheck ? "YES" : "NO") << "\n";
  std::cout << "  - Is Perfect: " << (isPerfect() ? "YES" : "NO") << "\n";
  std::cout << "  - Node Count: " << nodeCount << "\n";
  std::cout << "  - Height: " << height() << "\n";
  std::cout << "  - Balanced: " << (heightCheck ? "YES" : "NO") << "\n";

  return completeCheck;
}

// Вывод дерева
void CompleteBinaryTree::print() const {
  std::vector<int> levelOrderVec = levelOrder();
  std::cout << "Level Order: ";
  for (int val : levelOrderVec) {
    std::cout << val << " ";
  }
  std::cout << std::endl;
}

void CompleteBinaryTree::printTree() const {
  if (root == nullptr) {
    std::cout << "Empty tree" << std::endl;
    return;
  }

  std::queue<CBTNode *> q;
  q.push(root);
  int level = 0;

  while (!q.empty()) {
    int levelSize = q.size();
    std::cout << "Level " << level << ": ";

    for (int i = 0; i < levelSize; i++) {
      CBTNode *current = q.front();
      q.pop();

      std::cout << current->data;
      if (current->parent != nullptr) {
        std::cout << "(parent:" << current->parent->data << ") ";
      } else {
        std::cout << "(root) ";
      }

      if (current->left != nullptr) {
        q.push(current->left);
      }
      if (current->right != nullptr) {
        q.push(current->right);
      }
    }
    std::cout << std::endl;
    level++;
  }
}

std::string
CompleteBinaryTree::getNodeInfo(const CBTNode *node) { // Добавлен const
  if (node == nullptr) {
    return "";
  }
  std::string info = std::to_string(node->data);
  if (node->parent == nullptr) {
    info += " (ROOT)";
  } else {
    info += " (parent: " + std::to_string(node->parent->data) + ")";
  }
  return info;
}

// Сериализация - исправлено shadowing переменной size
void CompleteBinaryTree::serializeBinary(std::ostream &os) const {
  std::vector<int> levelOrderVec = levelOrder();
  size_t dataSize =
      levelOrderVec.size(); // Переименовано чтобы избежать shadowing
  os.write(reinterpret_cast<const char *>(&dataSize), sizeof(dataSize));
  if (dataSize > 0) {
    os.write(reinterpret_cast<const char *>(levelOrderVec.data()),
             dataSize * sizeof(int));
  }
}

void CompleteBinaryTree::deserializeBinary(std::istream &is) {
  // Очищаем текущее дерево
  deleteTree(root);
  root = nullptr;
  nodeCount = 0;

  size_t dataSize; // Переименовано чтобы избежать shadowing
  is.read(reinterpret_cast<char *>(&dataSize), sizeof(dataSize));

  if (dataSize > 0) {
    std::vector<int> data(dataSize);
    is.read(reinterpret_cast<char *>(data.data()), dataSize * sizeof(int));

    for (int value : data) {
      insert(value);
    }
  }
}

void CompleteBinaryTree::serializeText(std::ostream &os) const {
  std::vector<int> levelOrderVec = levelOrder();
  for (size_t i = 0; i < levelOrderVec.size(); ++i) {
    os << levelOrderVec[i];
    if (i < levelOrderVec.size() - 1) {
      os << " ";
    }
  }
}

void CompleteBinaryTree::deserializeText(std::istream &is) {
  // Очищаем текущее дерево
  deleteTree(root);
  root = nullptr;
  nodeCount = 0;

  int value;
  while (is >> value) {
    insert(value);
  }
}