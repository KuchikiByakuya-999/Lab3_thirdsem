#pragma once
#include <iostream>
#include <vector>

struct LNode {
  int data;
  LNode *next;
  LNode *prev;
  explicit LNode(int val)
      : data(val), next(nullptr), prev(nullptr) {} // Добавлен explicit
};

class DoublyLinkedList {
private:
  LNode *head;
  LNode *tail;

public:
  DoublyLinkedList();
  ~DoublyLinkedList();

  bool contains(int value) const;

  void pushFront(int value);
  void pushBack(int value);
  void insertBefore(int target, int value);
  void insertAfter(int target, int value);
  bool delByValue(int value);
  bool delFront();
  bool delBack();
  int get(int index) const; // Добавлен const
  void print() const;
  std::vector<int> toVector() const;

  void serializeBinary(std::ostream &os) const;
  void deserializeBinary(std::istream &is);
  void serializeText(std::ostream &os) const;
  void deserializeText(std::istream &is);
};