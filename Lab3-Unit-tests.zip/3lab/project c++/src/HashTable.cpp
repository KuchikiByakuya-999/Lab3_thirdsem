#include "../include/HashTable.h"
#include <algorithm>
#include <cmath>
#include <iostream>

int HashTable::foldingHash(int key, bool verbose) const {
  int sum = 0;
  int temp = std::abs(key); 

  if (verbose) {
    std::cout << "Folding hash для ключа " << key << ":\n";
    std::cout << "  Абсолютное значение: " << temp << "\n";
  }

  while (temp > 0) {
    int group = temp % 1000;
    sum += group;
    temp /= 1000;

    if (verbose) {
      std::cout << "  Группа: " << group << ", текущая сумма: " << sum << "\n";
    }
  }

  int result = sum % size;

  if (verbose) {
    std::cout << "  Финальная сумма: " << sum << ", хеш: " << result << "\n";
  }

  return result;
}

double HashTable::loadFactor() const {
  if (type == HashType::SEPARATE_CHAINING) {
    int occupied = 0;
    for (const auto& chain : chainTable) {
      if (!chain.empty()) {
        occupied++;
      }
    }
    return static_cast<double>(occupied) / size;
  } else {
    int occupied = std::count_if(table.begin(), table.end(),
                    [](const auto &slot) { return slot.has_value(); });
    return static_cast<double>(occupied) / size;
  }
}

void HashTable::rehash() {
  int newSize = size * 2 + 1;
  std::vector<std::optional<std::pair<int, int>>> newTable(newSize);

  for (const auto &slot : table) {
    if (slot.has_value()) {
      const auto &[key, value] = slot.value();
      int index = hashFunc1(key);
      int step = 1; // Линейное пробирование

      for (int i = 0; i < newSize; i++) {
        int probe = (index + i * step) % newSize;
        if (!newTable[probe].has_value()) {
          newTable[probe] = std::make_pair(key, value);
          break;
        }
      }
    }
  }

  table = std::move(newTable);
  size = newSize;
}

void HashTable::rehashChaining() {
  int newSize = size * 2 + 1;
  auto oldTable = std::move(chainTable);
  chainTable.resize(newSize);

  for (const auto& chain : oldTable) {
    for (const auto& pair : chain) {
      int index = hashFunc1(pair.first);
      chainTable[index].push_back(pair);
    }
  }

  size = newSize;
}

void HashTable::insertOpenAddressing(int key, int value) {
  int index = hashFunc1(key);
  int step = 1; // Линейное пробирование

  for (int i = 0; i < size; i++) {
    int probe = (index + i * step) % size;
    if (!table[probe].has_value() || table[probe]->first == key) {
      table[probe] = std::make_pair(key, value);
      return;
    }
  }
  
  // Если не нашли место, делаем rehash и пробуем снова
  rehash();
  insertOpenAddressing(key, value);
}

HashTable::HashTable(int s, HashType t)
    : size(std::max(s, 1)), type(t) { 
  if (type == HashType::SEPARATE_CHAINING) {
    chainTable.resize(size);
  } else {
    table.resize(size);
  }
}

// Вставка
void HashTable::insert(int key, int value) {
  // Проверяем коэффициент загрузки
  if (loadFactor() > 0.7) {
    if (type == HashType::SEPARATE_CHAINING) {
      rehashChaining();
    } else {
      rehash();
    }
  }

  switch (type) {
  case HashType::OPEN_ADDRESSING: {
    insertOpenAddressing(key, value);
    break;
  }

  case HashType::SEPARATE_CHAINING: {
    int index = hashFunc1(key);
    
    // Проверяем, не существует ли уже ключ
    for (auto it = chainTable[index].begin(); it != chainTable[index].end(); ++it) {
      if (it->first == key) {
        it->second = value; // Обновляем значение
        return;
      }
    }
    
    // Если ключ не найден, добавляем новый
    chainTable[index].push_back(std::make_pair(key, value));
    break;
  }

  case HashType::FOLDING_HASHING: {
    int index = foldingHash(key);
    int step = 1; // Линейное пробирование для folding

    for (int i = 0; i < size; i++) {
      int probe = (index + i * step) % size;
      if (!table[probe].has_value() || table[probe]->first == key) {
        table[probe] = std::make_pair(key, value);
        return;
      }
    }
    break;
  }
  }
}

// Удаление
bool HashTable::remove(int key) {
  switch (type) {
  case HashType::OPEN_ADDRESSING: {
    int index = hashFunc1(key);
    int step = 1;

    for (int i = 0; i < size; i++) {
      int probe = (index + i * step) % size;
      if (table[probe].has_value() && table[probe]->first == key) {
        table[probe].reset();
        return true;
      }
      if (!table[probe].has_value()) {
        break; // Конец цепочки
      }
    }
    break;
  }

  case HashType::SEPARATE_CHAINING: {
    int index = hashFunc1(key);
    
    for (auto it = chainTable[index].begin(); it != chainTable[index].end(); ++it) {
      if (it->first == key) {
        chainTable[index].erase(it);
        return true;
      }
    }
    break;
  }

  case HashType::FOLDING_HASHING: {
    int index = foldingHash(key);
    int step = 1;

    for (int i = 0; i < size; i++) {
      int probe = (index + i * step) % size;
      if (table[probe].has_value() && table[probe]->first == key) {
        table[probe].reset();
        return true;
      }
      if (!table[probe].has_value()) {
        break;
      }
    }
    break;
  }
  }

  return false;
}

// Поиск
std::optional<int> HashTable::get(int key) const {
  switch (type) {
  case HashType::OPEN_ADDRESSING: {
    int index = hashFunc1(key);
    int step = 1;

    for (int i = 0; i < size; i++) {
      int probe = (index + i * step) % size;
      if (table[probe].has_value() && table[probe]->first == key) {
        return table[probe]->second;
      }
      if (!table[probe].has_value()) {
        break;
      }
    }
    break;
  }

  case HashType::SEPARATE_CHAINING: {
    int index = hashFunc1(key);
    
    for (const auto& pair : chainTable[index]) {
      if (pair.first == key) {
        return pair.second;
      }
    }
    break;
  }

  case HashType::FOLDING_HASHING: {
    int index = foldingHash(key);
    int step = 1;

    for (int i = 0; i < size; i++) {
      int probe = (index + i * step) % size;
      if (table[probe].has_value() && table[probe]->first == key) {
        return table[probe]->second;
      }
      if (!table[probe].has_value()) {
        break;
      }
    }
    break;
  }
  }

  return std::nullopt;
}

// Преобразование в вектор
std::vector<std::pair<int, int>> HashTable::toVector() const {
  std::vector<std::pair<int, int>> result;
  
  if (type == HashType::SEPARATE_CHAINING) {
    for (const auto& chain : chainTable) {
      for (const auto& pair : chain) {
        result.push_back(pair);
      }
    }
  } else {
    for (const auto &slot : table) {
      if (slot.has_value()) {
        result.push_back(slot.value());
      }
    }
  }
  
  return result;
}

// Очистка
void HashTable::clear() {
  if (type == HashType::SEPARATE_CHAINING) {
    for (auto& chain : chainTable) {
      chain.clear();
    }
  } else {
    for (auto &slot : table) {
      slot.reset();
    }
  }
}

// Вывод
void HashTable::print() const {
  std::cout << "Hash Table (Size: " << size << ", Type: ";
  switch (type) {
    case HashType::OPEN_ADDRESSING: std::cout << "Open Addressing"; break;
    case HashType::SEPARATE_CHAINING: std::cout << "Separate Chaining"; break;
    case HashType::FOLDING_HASHING: std::cout << "Folding Hashing"; break;
  }
  std::cout << "):\n";
  
  if (type == HashType::SEPARATE_CHAINING) {
    for (int i = 0; i < size; i++) {
      std::cout << "  [" << i << "]: ";
      if (chainTable[i].empty()) {
        std::cout << "EMPTY";
      } else {
        for (const auto& pair : chainTable[i]) {
          std::cout << "(" << pair.first << ", " << pair.second << ") ";
        }
      }
      std::cout << "\n";
    }
  } else {
    for (int i = 0; i < size; i++) {
      std::cout << "  [" << i << "]: ";
      if (table[i].has_value()) {
        std::cout << "(" << table[i]->first << ", " << table[i]->second << ")";
      } else {
        std::cout << "EMPTY";
      }
      std::cout << "\n";
    }
  }
  std::cout << "Load Factor: " << loadFactor() << "\n";
}

// Сериализация
void HashTable::serializeBinary(std::ostream &os) const {
  // Сохраняем тип и размер
  int typeInt = static_cast<int>(type);
  os.write(reinterpret_cast<const char *>(&typeInt), sizeof(typeInt));
  os.write(reinterpret_cast<const char *>(&size), sizeof(size));

  if (type == HashType::SEPARATE_CHAINING) {
    // Для separate chaining сохраняем количество элементов в каждой цепочке
    for (const auto& chain : chainTable) {
      int chainSize = chain.size();
      os.write(reinterpret_cast<const char *>(&chainSize), sizeof(chainSize));
      for (const auto& pair : chain) {
        os.write(reinterpret_cast<const char *>(&pair.first), sizeof(pair.first));
        os.write(reinterpret_cast<const char *>(&pair.second), sizeof(pair.second));
      }
    }
  } else {
    // Для open addressing и folding hashing
    for (const auto &slot : table) {
      bool hasValue = slot.has_value();
      os.write(reinterpret_cast<const char *>(&hasValue), sizeof(hasValue));
      if (hasValue) {
        os.write(reinterpret_cast<const char *>(&slot->first), sizeof(slot->first));
        os.write(reinterpret_cast<const char *>(&slot->second), sizeof(slot->second));
      }
    }
  }
}

void HashTable::deserializeBinary(std::istream &is) {
  // Читаем тип и размер
  int typeInt;
  is.read(reinterpret_cast<char *>(&typeInt), sizeof(typeInt));
  type = static_cast<HashType>(typeInt);
  is.read(reinterpret_cast<char *>(&size), sizeof(size));

  if (type == HashType::SEPARATE_CHAINING) {
    chainTable.resize(size);
    for (int i = 0; i < size; i++) {
      int chainSize;
      is.read(reinterpret_cast<char *>(&chainSize), sizeof(chainSize));
      for (int j = 0; j < chainSize; j++) {
        int key, value;
        is.read(reinterpret_cast<char *>(&key), sizeof(key));
        is.read(reinterpret_cast<char *>(&value), sizeof(value));
        chainTable[i].push_back(std::make_pair(key, value));
      }
    }
  } else {
    table.resize(size);
    for (int i = 0; i < size; i++) {
      bool hasValue;
      is.read(reinterpret_cast<char *>(&hasValue), sizeof(hasValue));
      if (hasValue) {
        int key;
        int value;
        is.read(reinterpret_cast<char *>(&key), sizeof(key));
        is.read(reinterpret_cast<char *>(&value), sizeof(value));
        table[i] = std::make_pair(key, value);
      } else {
        table[i].reset();
      }
    }
  }
}

void HashTable::serializeText(std::ostream &os) const {
  os << static_cast<int>(type) << " " << size << "\n";
  
  if (type == HashType::SEPARATE_CHAINING) {
    for (const auto& chain : chainTable) {
      for (const auto& pair : chain) {
        os << pair.first << " " << pair.second << "\n";
      }
    }
  } else {
    for (const auto &slot : table) {
      if (slot.has_value()) {
        os << slot->first << " " << slot->second << "\n";
      }
    }
  }
}

void HashTable::deserializeText(std::istream &is) {
  int typeInt;
  is >> typeInt >> size;
  type = static_cast<HashType>(typeInt);

  if (type == HashType::SEPARATE_CHAINING) {
    chainTable.resize(size);
    for (auto& chain : chainTable) {
      chain.clear();
    }
  } else {
    table.resize(size);
    for (int i = 0; i < size; i++) {
      table[i].reset();
    }
  }

  int key;
  int value;
  while (is >> key >> value) {
    insert(key, value);
  }
}